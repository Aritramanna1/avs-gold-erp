const translations = {
  // Page headers / metadata
  title: "ऑर्डर सूची",
  subtitle: "ग्राहकांच्या दागिने डिझाइन ऑर्डर्स शोधा व व्यवस्थापित करा.",
  newOrder: "नवीन ऑर्डर",
  createOrder: "ऑर्डर तयार करा",
  orderDetail: "ऑर्डर सविस्तर माहिती",
  orderNotFound: "ऑर्डर आढळली नाही",
  orderNotFoundDesc: "ती कदाचित हटवली गेली असावी.",
  backToOrders: "सर्व ऑर्डरवर परत जा",
  allOrders: "सर्व ऑर्डर्स",
  workflow: "कार्यप्रवाह",

  // Search & Filters
  searchPlaceholder: "ऑर्डर क्रमांक, ग्राहक किंवा वस्तूद्वारे शोधा...",
  statusPlaceholder: "स्थिती",
  allStatuses: "सर्व स्थिती",
  orderTypePlaceholder: "ऑर्डर प्रकार",
  allTypes: "सर्व प्रकार",
  placeholderStatus: "स्थिती",
  placeholderType: "ऑर्डर प्रकार",

  // No Orders empty State
  noOrdersTitle: "अद्याप कोणतीही ऑर्डर नाही",
  noOrdersDesc: "कार्यप्रवाह सुरू करण्यासाठी पहिली ऑर्डर तयार करा.",

  // Table Headers
  orderNoCol: "ऑर्डर क्र.",
  dateCol: "दिनांक",
  customerCol: "ग्राहक",
  itemCol: "दागिना",
  typeCol: "प्रकार",
  fineGoldCol: "शुद्ध सोने",
  deliveryCol: "वितरण",
  statusCol: "स्थिती",
  actionCol: "कृती",

  // Table row text & badges
  delayed: "विलंब",
  tomorrow: "उद्या",
  today: "आज",
  remind: "आठवण करून द्या",
  view: "पहा",

  // Badges & Labels
  status_draft: "मसुदा",
  status_confirmed: "निश्चित केले",
  status_awaiting_job_card: "जॉब कार्ड प्रतीक्षेत",
  status_in_production: "उत्पादनात",
  status_ready_billing: "बिलिंगसाठी तयार",
  status_delivered: "वितरीत केले",
  status_cancelled: "रद्द केले",
  status_received: "प्राप्त झाले",
  status_gold_received: "सोने प्राप्त झाले",
  status_gold_issued: "सोने दिले",
  status_sent_to_worker: "कामगाराकडे पाठवले",
  status_in_manufacturing: "उत्पादन सुरू",
  status_under_inspection: "तपासणी सुरू",
  status_sent_for_polishing: "पॉलिशिंगसाठी पाठवले",
  status_polishing_in_progress: "पॉलिशिंग सुरू",
  status_ready: "तयार",
  status_ready_for_delivery: "वितरणासाठी तयार",
  status_partially_ready: "अंशतः तयार",
  status_partially_delivered: "अंशतः वितरित",
  status_billed: "बिलिंग पूर्ण",
  status_repair_in_progress: "दुरुस्ती सुरू",

  type_custom: "सानुकूल ऑर्डर",
  type_repair: "दुरुस्ती",
  type_polishing: "पॉलिशिंग",
  type_ready_stock: "स्टॉकमधून विक्री",
  type_wholesale: "घाऊक / मोठ्या प्रमाणात",

  priority_normal: "सामान्य",
  priority_high: "उच्च",
  priority_urgent: "तातडीचे",

  priorityLabel: "प्राथमिकता",
  orderSlip: "ऑर्डर स्लिप",
  oldGoldReceipt: "जुने सोने पावती",
  customerGoldReceipt: "ग्राहक सोने पावती",
  advanceReceipt: "अॅडव्हान्स पावती",
  createOrderSubtitle:
    "चरण-दर-चरण ऑर्डर नोंदणी. तुम्ही निश्चित करेपर्यंत किंवा मसुदा जतन करेपर्यंत काहीही जतन केले जात नाही.",
  step_1: "ऑर्डर प्रकार",
  step_2: "ग्राहक",
  step_3: "डिझाइन",
  step_4: "वस्तू आणि सोने",
  step_5: "अॅडव्हान्स / सोने जमा",
  step_6: "कामगार सोपवणे",
  step_7: "निश्चित करा",
};

export default translations;
