const translations = {
  title: "खर्च वहन ट्रॅकर",
  subtitle: "दुकानाचा कारभार, गुंतवणूक आणि वैयक्तिक प्रोफाइल संबंधित सर्व खर्च व्यवस्थापित करा.",
};

export default translations;
