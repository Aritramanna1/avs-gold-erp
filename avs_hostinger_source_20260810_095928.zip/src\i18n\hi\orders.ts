const translations = {
  // Page headers / metadata
  title: "ऑर्डर सूची",
  subtitle: "ग्राहकों के आभूषण डिज़ाइन ऑर्डर खोजें और प्रबंधित करें।",
  newOrder: "नया ऑर्डर",
  createOrder: "ऑर्डर बनाएं",
  orderDetail: "ऑर्डर का विवरण",
  orderNotFound: "ऑर्डर नहीं मिला",
  orderNotFoundDesc: "शायद इसे हटा दिया गया है।",
  backToOrders: "सभी ऑर्डर्स पर वापस जाएं",
  allOrders: "सभी ऑर्डर्स",
  workflow: "कार्यप्रवाह",

  // Search & Filters
  searchPlaceholder: "ऑर्डर नंबर, ग्राहक या आइटम खोजें...",
  statusPlaceholder: "स्थिति",
  allStatuses: "सभी स्थितियां",
  orderTypePlaceholder: "ऑर्डर प्रकार",
  allTypes: "सभी प्रकार",
  placeholderStatus: "स्थिति",
  placeholderType: "ऑर्डर प्रकार",

  // No Orders empty State
  noOrdersTitle: "अभी तक कोई ऑर्डर नहीं",
  noOrdersDesc: "कार्यप्रवाह शुरू करने के लिए पहला ऑर्डर बनाएं।",

  // Table Headers
  orderNoCol: "ऑर्डर नंबर",
  dateCol: "दिनांक",
  customerCol: "ग्राहक",
  itemCol: "आइटम",
  typeCol: "प्रकार",
  fineGoldCol: "शुद्ध सोना",
  deliveryCol: "वितरण",
  statusCol: "स्थिति",
  actionCol: "क्रिया",

  // Table row text & badges
  delayed: "विलंबित",
  tomorrow: "कल",
  today: "आज",
  remind: "स्मरण दिलाएं",
  view: "देखें",

  // Badges & Labels
  status_draft: "ड्राफ्ट",
  status_confirmed: "पुष्टि की गई",
  status_awaiting_job_card: "जॉब कार्ड की प्रतीक्षा",
  status_in_production: "उत्पादन में",
  status_ready_billing: "बिलिंग के लिए तैयार",
  status_delivered: "वितरित",
  status_cancelled: "रद्द",
  status_received: "प्राप्त हुआ",
  status_gold_received: "सोना प्राप्त हुआ",
  status_gold_issued: "सोना जारी किया गया",
  status_sent_to_worker: "कारीगर के पास भेजा गया",
  status_in_manufacturing: "विनिर्माण में",
  status_under_inspection: "निरीक्षण के अधीन",
  status_sent_for_polishing: "पॉलिशिंग के लिए भेजा गया",
  status_polishing_in_progress: "पॉलिशिंग प्रगति पर है",
  status_ready: "तैयार",
  status_ready_for_delivery: "वितरण के लिए तैयार",
  status_partially_ready: "आंशिक रूप से तैयार",
  status_partially_delivered: "आंशिक रूप से वितरित",
  status_billed: "बिल किया गया",
  status_repair_in_progress: "मरम्मत प्रगति पर है",

  type_custom: "कस्टम ऑर्डर",
  type_repair: "मरम्मत",
  type_polishing: "पॉलिशिंग",
  type_ready_stock: "स्टॉक से बिक्री",
  type_wholesale: "थोक / थोक ऑर्डर",

  priority_normal: "सामान्य",
  priority_high: "उच्च",
  priority_urgent: "अति आवश्यक",

  priorityLabel: "प्राथमिकता",
  orderSlip: "ऑर्डर स्लिप",
  oldGoldReceipt: "पुराने सोने की रसीद",
  customerGoldReceipt: "ग्राहक सोने की रसीद",
  advanceReceipt: "अग्रिम भुगतान की रसीद",
  createOrderSubtitle:
    "चरण-दर-चरण ऑर्डर प्रविष्टि। जब तक आप पुष्टि नहीं करते या ड्राफ्ट सहेजते नहीं, तब तक कुछ भी सहेजा नहीं जाता है।",
  step_1: "ऑर्डर का प्रकार",
  step_2: "ग्राहक",
  step_3: "डिज़ाइन",
  step_4: "आइटम और सोना",
  step_5: "अग्रिम / सोना जमा",
  step_6: "कारीगर आवंटन",
  step_7: "पुष्टि करें",
};

export default translations;
