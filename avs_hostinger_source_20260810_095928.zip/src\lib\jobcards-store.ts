/**
 * MTJ ERP — Job Cards store (Phase 5)
 * Manufacturing spine: Order → Job Card → (Worker Issue) → (Receive Work) → ...
 *
 * Weights in mg (integer), purity per-mille.
 */
import { create } from "zustand";
import type { Priority } from "./orders-store";
import { useWorkerGoldBook } from "./worker-gold-book-store";
import { useSettings } from "./settings-store";
import { dataProvider as supabase } from "@/lib/providers/data-provider";
import { createRepository } from "./repositories/base-repository";
import { nextDocumentNumber } from "./document-numbering";

/**
 * The Job Card's life, as a workshop actually lives it.
 *
 * Each status answers one question — WHERE IS THE GOLD, AND WHOSE HANDS IS THE
 * PIECE IN? That is the only thing a manufacturer needs a job status to tell
 * them, and it's what makes each of these worth a distinct state:
 *
 *   awaiting_gold_issue → card written, karigar assigned, gold still in the vault
 *   gold_issued         → gold is out of the vault and in the karigar's custody
 *   in_progress         → the karigar has started making the piece
 *   work_received       → piece is back with us and is being checked (weight, finish, stones)
 *   rework              → checked and sent back to the bench
 *   ready_for_billing   → passed; the piece is ours and can be invoiced
 *   closed              → done
 *
 * Two statuses were removed as meaningless:
 *  - `draft`: cards are now created deliberately, with a karigar chosen. A card
 *    that exists is real work; there is nothing to draft.
 *  - `qc_pending`: identical in practice to `work_received` — the piece is back
 *    and being checked. Two names for one state is how two people give you two
 *    different answers about the same job.
 *
 * `ready_for_gold_issue` is renamed to `awaiting_gold_issue` (clearer: it is
 * WAITING on us, not "ready" in the sense of finished).
 *
 * Old values still exist in saved records, so they remain in the type as legacy
 * and are folded into the live ones by `normalizeJobStatus()` on read. Nothing
 * writes them any more.
 */
export type JobStatus =
  | "awaiting_gold_issue"
  | "gold_issued"
  | "in_progress"
  | "work_received"
  | "rework"
  | "ready_for_billing"
  | "closed"
  // ── Legacy, read-only. Normalized away on read; never written. ──
  | "draft"
  | "ready_for_gold_issue"
  | "qc_pending";

/** The live workflow, in order. Anything not here is legacy. */
export const JOB_STATUS_FLOW: JobStatus[] = [
  "awaiting_gold_issue",
  "gold_issued",
  "in_progress",
  "work_received",
  "rework",
  "ready_for_billing",
  "closed",
];

export const JOB_STATUS_LABELS: Record<JobStatus, string> = {
  awaiting_gold_issue: "Awaiting Gold Issue",
  gold_issued: "Gold Issued",
  in_progress: "Work In Progress",
  work_received: "Work Received (Checking)",
  rework: "Rework",
  ready_for_billing: "Ready for Billing",
  closed: "Closed",

  // Legacy — labelled as their live equivalent so an old record never displays
  // a status the workflow no longer has.
  draft: "Awaiting Gold Issue",
  ready_for_gold_issue: "Awaiting Gold Issue",
  qc_pending: "Work Received (Checking)",
};

/**
 * Folds a stored status onto the live workflow. Every read of a Job Card's
 * status must go through this — a card saved months ago as `qc_pending` should
 * show up in today's "Work Received" bucket, not vanish from every filter.
 */
export function normalizeJobStatus(status: JobStatus): JobStatus {
  switch (status) {
    case "draft":
    case "ready_for_gold_issue":
      return "awaiting_gold_issue";
    case "qc_pending":
      return "work_received";
    default:
      return status;
  }
}

/** @deprecated Use JOB_STATUS_FLOW. */
export const JOB_STATUS_ACTIVE: JobStatus[] = JOB_STATUS_FLOW;

export interface JobTimelineEvent {
  ts: number;
  label: string;
  note?: string;
}

export interface QAFlags {
  finishOk: boolean;
  weightChecked: boolean;
  stoneChecked: boolean;
  readyForStock: boolean;
}

export interface WorkReceiptRecord {
  id: string;
  slipNo: string;
  ts: number;
  finishedGrossMg: number;
  finishedPurity: number;
  finishedFineMg: number;
  scrapGrossMg: number;
  scrapPurity: number;
  scrapFineMg: number;
  filingsGrossMg: number;
  filingsPurity: number;
  filingsFineMg: number;
  dustFineMg: number;
  expectedWastagePct: number; // 0..100
  expectedLossMg: number;
  actualLossMg: number;
  overlossMg: number;
  qa: QAFlags;
  notes?: string;
  finishedStockId?: string;
  ledgerEntryIds: string[];
}

export interface JobCard {
  id: string;
  jobNo: string;
  createdAt: number;
  updatedAt: number;

  // links
  orderId: string;
  orderNo: string;
  customerId: string;
  customerName: string;
  karigarId?: string;
  karigarName?: string;

  // item target (snapshot from order)
  /**
   * Which line of the order this card is for. An order holds several pieces and
   * each one is an independent bench job, so the card must know its line — both
   * to pull that line's reference photos and so re-confirming an order doesn't
   * duplicate cards for lines that already have one.
   */
  lineId?: string;
  itemName: string;
  category: string;
  /** Category-specific dimensions (ring size, chain length) — snapshot of the order line's. */
  attributes?: Record<string, string>;
  /** Pieces to make on THIS card. Target weights below are for all of them. */
  quantity?: number;
  /** Expected weight of one piece; targetGrossMg is the total for `quantity` pieces. */
  perPieceGrossMg?: number;
  purity: number;
  targetGrossMg: number;
  targetNetMg: number;
  targetFineMg: number;
  expectedWastagePct?: number;

  // workshop
  status: JobStatus;
  priority: Priority;
  expectedDelivery?: string;
  expectedStart?: string;
  expectedCompletion?: string;
  notes?: string;
  branchId?: string;

  // gold movement
  workReceipt?: WorkReceiptRecord;

  timeline: JobTimelineEvent[];
}

interface JobCardsState {
  jobs: JobCard[];
  refresh: () => Promise<void>;
  add: (
    input: Omit<JobCard, "id" | "createdAt" | "updatedAt" | "timeline" | "jobNo"> & {
      jobNo?: string;
      timeline?: JobTimelineEvent[];
    },
  ) => Promise<JobCard>;
  update: (id: string, patch: Partial<JobCard>) => Promise<void>;
  remove: (id: string) => Promise<void>;
  appendTimeline: (id: string, ev: JobTimelineEvent) => Promise<void>;
  /** Sets the Job Card's overall status directly — replaces the old per-step-derived status transition. */
  setStatus: (jobId: string, status: JobStatus, notes?: string) => Promise<void>;
  setWorkReceipt: (jobId: string, rec: WorkReceiptRecord) => Promise<void>;
  reset: () => void;
}

export interface KarigarCustodySummary {
  karigarId: string;
  karigarName: string;
  issuedMg: number;
  finishedMg: number;
  scrapMg: number;
  filingsMg: number;
  wastageMg: number;
  overlossMg: number;
  outstandingMg: number;
  jobs: { jobId: string; jobNo: string; outstandingMg: number }[];
}

export function karigarCustodySummaries(jobs: JobCard[]): KarigarCustodySummary[] {
  const map = new Map<string, KarigarCustoryIntermediate>();

  interface KarigarCustoryIntermediate {
    karigarId: string;
    karigarName: string;
    issuedMg: number;
    finishedMg: number;
    scrapMg: number;
    filingsMg: number;
    wastageMg: number;
    overlossMg: number;
    outstandingMg: number;
    jobs: { jobId: string; jobNo: string; outstandingMg: number }[];
  }

  // Get all unique workers who have entries in the Worker Gold Book
  const wStore = useWorkerGoldBook.getState();
  const allEntries = wStore.entries;
  const uniqueWorkerIds = Array.from(new Set(allEntries.map((e) => e.workerId)));

  for (const workerId of uniqueWorkerIds) {
    const workerEntries = allEntries.filter((e) => e.workerId === workerId);
    if (workerEntries.length === 0) continue;

    const workerName = workerEntries[0].workerName;
    const bal = wStore.getWorkerBalance(workerId);

    let finishedMg = 0;
    let scrapMg = 0;
    let filingsMg = 0;
    let wastageMg = 0;

    workerEntries.forEach((e) => {
      if (e.type === "return") {
        if (e.particulars.startsWith("Finished:")) {
          finishedMg += e.fineMg;
        } else if (e.particulars === "Scrap Returned") {
          scrapMg += e.fineMg;
        } else if (e.particulars === "Filings Returned") {
          filingsMg += e.fineMg;
        } else if (
          e.particulars === "Melt Loss / Wastage" ||
          e.particulars === "Dust/Sweepings Returned"
        ) {
          wastageMg += e.fineMg;
        }
      }
    });

    const activeJobsForWorker = jobs.filter((j) => j.karigarId === workerId);
    const workerJobsList = activeJobsForWorker.map((j) => ({
      jobId: j.id,
      jobNo: j.jobNo,
      outstandingMg: 0,
    }));

    map.set(workerId, {
      karigarId: workerId,
      karigarName: workerName,
      issuedMg: bal.totalGivenFine,
      finishedMg,
      scrapMg,
      filingsMg,
      wastageMg,
      overlossMg: 0,
      outstandingMg: bal.pendingFine,
      jobs: workerJobsList,
    });
  }

  return Array.from(map.values()).sort((a, b) => b.outstandingMg - a.outstandingMg);
}

function makeId() {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) return crypto.randomUUID();
  return `j_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
}

const jobCardRepository = createRepository<JobCard>("job_cards");

async function makeJobNo(): Promise<string> {
  const d = new Date();
  const yyyymmdd = `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, "0")}${String(d.getDate()).padStart(2, "0")}`;
  const prefix = `JC-${yyyymmdd}-`;
  return nextDocumentNumber(`job_card:${yyyymmdd}`, prefix, 3);
}

export const useJobCards = create<JobCardsState>()((set, get) => ({
  jobs: [],
  refresh: async () => {
    const { currentUserRole, selectedBranchId } = useSettings.getState();
    const GLOBAL_ROLES = ["Super Owner", "Administrator", "CEO (View Only)"];
    const bid =
      !currentUserRole || GLOBAL_ROLES.includes(currentUserRole)
        ? null
        : selectedBranchId || "MAIN";
    let q = supabase.from("job_cards").select("data").limit(10000);
    if (bid) q = q.filter("data->>branchId", "eq", bid) as typeof q;
    const { data, error } = await q;
    if (error) {
      // DB error on refresh — leave existing state
      return;
    }
    const rows = (data ?? [])
      .map((r) => r.data as JobCard | null)
      .filter((j): j is JobCard => !!j && !!j.id && !!j.jobNo)
      // Fold legacy statuses (draft / ready_for_gold_issue / qc_pending) onto
      // the live workflow HERE, so no screen, filter or report has to know the
      // old names ever existed.
      .map((j) => ({ ...j, status: normalizeJobStatus(j.status) }));
    set({ jobs: rows });
  },
  add: async (input) => {
    const now = Date.now();
    const job: JobCard = {
      branchId: (input as any).branchId ?? useSettings.getState().selectedBranchId ?? undefined,
      id: makeId(),
      createdAt: now,
      updatedAt: now,
      ...input,
      jobNo: input.jobNo ?? (await makeJobNo()),
      timeline: input.timeline ?? [{ ts: now, label: "Job Card created" }],
    };
    await jobCardRepository.save(job);
    await get().refresh();
    return job;
  },
  update: async (id, patch) => {
    const current = get().jobs.find((j) => j.id === id);
    if (!current) return;
    const updated = { ...current, ...patch, updatedAt: Date.now() };
    await jobCardRepository.save(updated);
    await get().refresh();
  },
  remove: async (id) => {
    await jobCardRepository.delete(id);
    await get().refresh();
  },
  appendTimeline: async (id, ev) => {
    const current = get().jobs.find((j) => j.id === id);
    if (!current) return;
    const updated = {
      ...current,
      timeline: [...current.timeline, ev],
      updatedAt: Date.now(),
    };
    await jobCardRepository.save(updated);
    await get().refresh();
  },
  setStatus: async (jobId, status, notes) => {
    const now = Date.now();
    const current = get().jobs.find((j) => j.id === jobId);
    if (!current) return;
    const updated = {
      ...current,
      status,
      updatedAt: now,
      timeline: [
        ...current.timeline,
        {
          ts: now,
          label: `Status → ${JOB_STATUS_LABELS[status]}`,
          note: notes,
        },
      ],
    };
    await jobCardRepository.save(updated);
    await get().refresh();
  },

  setWorkReceipt: async (jobId, rec) => {
    const current = get().jobs.find((j) => j.id === jobId);
    if (!current) return;
    const updated = {
      ...current,
      workReceipt: rec,
      status: "work_received" as JobStatus,
      updatedAt: Date.now(),
      timeline: [
        ...current.timeline,
        {
          ts: rec.ts,
          label: `Work received · ${rec.slipNo}`,
          note: rec.overlossMg > 0 ? `Overloss ${(rec.overlossMg / 1000).toFixed(3)} g` : undefined,
        },
      ],
    };
    await jobCardRepository.save(updated);
    await get().refresh();
    try {
      const [{ append: appendAudit }, { supabase: sb }] = await Promise.all([
        import("./security/audit-log"),
        import("@/lib/providers/data-provider"),
      ]);
      const { data } = await sb.auth.getSession();
      await appendAudit({
        actorId: data.session?.user.id ?? null,
        actorEmail: data.session?.user.email ?? null,
        action: "job_card.work_receipt",
        entityType: "job_cards",
        entityId: jobId,
        before: null,
        after: rec,
        deviceId: null,
      });
    } catch (err) {
      console.error("[JobCards] Failed to audit-log work receipt:", err);
    }
  },
  reset: () => set({ jobs: [] }),
}));
