﻿# AVS PRODUCTION BASELINE — CVsE73i6 (FROZEN)

**Status:** IMMUTABLE. Do not overwrite, merge into, or mix with other versions.

## Equation

```
BASELINE = index-CVsE73i6.js
         = git 8dc1c438214a5e3192e15dc95b7708de24ca6baf (production-baseline-cvse73i6)
         = dist_go_20260826_190800.zip
```

## Roles

| Role | Location |
|------|----------|
| BASELINE | this folder (frozen) |
| DEVELOPMENT | `main` |
| IMPLEMENTATION | from this baseline only |
| BUILD | from `main` |
| DEPLOY | build produced from `main` |

## Contents

- `production-artifact/` — exact `index-CVsE73i6.js` + recovery zip + dist extract
- `source/` — corresponding source at git `8dc1c438214a5e3192e15dc95b7708de24ca6baf`
- `approved-docs/` — documentation at that commit
- `configuration/` — key config snapshots
- `migrations-ref/` — migration files + list
- `print-customization-refs/` — print/customization docs + source
- `mtj-offline-erp-refs/` — MTJ/Offline ERP reference docs
- `qa-evidence/` — QA tree from baseline + freeze note
- `BASELINE_MANIFEST.json` / `FROZEN.lock`

## Verification (performed at freeze)

- `main` is a descendant of `8dc1c438214a5e3192e15dc95b7708de24ca6baf` (YES)
- Zip SHA256: `D221ECCB7DAFB3309209094632BBD143EF28A747159693DC8F9B0E51ECF018AA`
- index-CVsE73i6.js SHA256: `DDE3DCBECA50D0EE30882C0B98B25D8E95E8B1429319EFBD31720C61518D08D8`
- Zip-extracted index matches extract copy (YES)

## Immutable backup

Sibling host path: `C:\avs-test-install\AVS_PRODUCTION_BASELINE_CVsE73i6_IMMUTABLE_BACKUP`

Never delete the recovery zip. Never switch implementation baseline again.
