import{i as e,n as t,t as n}from"./rolldown-runtime-aKtaBQYM.js";var r=n(((e,t)=>{t.exports={}})),i=e(n(((e,t)=>{var n=void 0,i=function(e){return n||(n=new Promise(function(n,i){var a=e===void 0?{}:e,o=a.onAbort;a.onAbort=function(e){i(Error(e)),o&&o(e)},a.postRun=a.postRun||[],a.postRun.push(function(){n(a)}),t=void 0;var s;s||=a===void 0?{}:a;var c=!!globalThis.window,l=!!globalThis.WorkerGlobalScope,u=globalThis.process?.versions?.node&&globalThis.process?.type!=`renderer`;s.onRuntimeInitialized=function(){function e(e,t){switch(typeof t){case`boolean`:fe(e,+!!t);break;case`number`:ue(e,t);break;case`string`:j(e,t,-1,-1);break;case`object`:if(t===null)de(e);else if(t.length!=null){var n=jt(t.length);S.set(t,n),M(e,n,t.length,-1),Mt(n)}else F(e,`Wrong API use : tried to return a value of an unknown type (`+t+`).`,-1);break;default:de(e)}}function t(e,t){for(var n=[],r=0;r<e;r+=1){var i=N(t+4*r,`i32`),a=ae(i);if(a===1||a===2)i=le(i);else if(a===3)i=se(i);else if(a===4){a=i,i=oe(a),a=ce(a);for(var o=new Uint8Array(i),s=0;s<i;s+=1)o[s]=S[a+s];i=o}else i=null;n.push(i)}return n}function n(e,t){this.Qa=e,this.db=t,this.Oa=1,this.mb=[]}function r(e,t){if(this.db=t,this.fb=wt(e),this.fb===null)throw Error(`Unable to allocate memory for the SQL string`);this.lb=this.fb,this.$a=this.sb=null}function i(e){if(this.filename=`dbfile_`+(4294967295*Math.random()>>>0),e!=null){var t=this.filename,n=`/`,r=t;if(n&&(n=typeof n==`string`?n:Me(n),r=t?L(n+`/`+t):n),t=we(!0,!0),r=Je(r,t),e){if(typeof e==`string`){n=Array(e.length);for(var i=0,o=e.length;i<o;++i)n[i]=e.charCodeAt(i);e=n}tt(r,t|146),n=rt(r,577),st(n,e,0,e.length,0),it(n),tt(r,t)}}this.handleError(c(this.filename,a)),this.db=N(a,`i32`),me(this.db),this.gb={},this.Sa={}}var a=It(4),o=s.cwrap,c=o(`sqlite3_open`,`number`,[`string`,`number`]),l=o(`sqlite3_close_v2`,`number`,[`number`]),u=o(`sqlite3_exec`,`number`,[`number`,`string`,`number`,`number`,`number`]),d=o(`sqlite3_changes`,`number`,[`number`]),f=o(`sqlite3_prepare_v2`,`number`,[`number`,`string`,`number`,`number`,`number`]),p=o(`sqlite3_sql`,`string`,[`number`]),ee=o(`sqlite3_normalized_sql`,`string`,[`number`]),m=o(`sqlite3_prepare_v2`,`number`,[`number`,`number`,`number`,`number`,`number`]),h=o(`sqlite3_bind_text`,`number`,[`number`,`number`,`number`,`number`,`number`]),g=o(`sqlite3_bind_blob`,`number`,[`number`,`number`,`number`,`number`,`number`]),_=o(`sqlite3_bind_double`,`number`,[`number`,`number`,`number`]),v=o(`sqlite3_bind_int`,`number`,[`number`,`number`,`number`]),y=o(`sqlite3_bind_parameter_index`,`number`,[`number`,`string`]),b=o(`sqlite3_step`,`number`,[`number`]),x=o(`sqlite3_errmsg`,`string`,[`number`]),te=o(`sqlite3_column_count`,`number`,[`number`]),C=o(`sqlite3_data_count`,`number`,[`number`]),w=o(`sqlite3_column_double`,`number`,[`number`,`number`]),T=o(`sqlite3_column_text`,`string`,[`number`,`number`]),E=o(`sqlite3_column_blob`,`number`,[`number`,`number`]),ne=o(`sqlite3_column_bytes`,`number`,[`number`,`number`]),D=o(`sqlite3_column_type`,`number`,[`number`,`number`]),O=o(`sqlite3_column_name`,`string`,[`number`,`number`]),re=o(`sqlite3_reset`,`number`,[`number`]),k=o(`sqlite3_clear_bindings`,`number`,[`number`]),ie=o(`sqlite3_finalize`,`number`,[`number`]),A=o(`sqlite3_create_function_v2`,`number`,`number string number number number number number number number`.split(` `)),ae=o(`sqlite3_value_type`,`number`,[`number`]),oe=o(`sqlite3_value_bytes`,`number`,[`number`]),se=o(`sqlite3_value_text`,`string`,[`number`]),ce=o(`sqlite3_value_blob`,`number`,[`number`]),le=o(`sqlite3_value_double`,`number`,[`number`]),ue=o(`sqlite3_result_double`,``,[`number`,`number`]),de=o(`sqlite3_result_null`,``,[`number`]),j=o(`sqlite3_result_text`,``,[`number`,`string`,`number`,`number`]),M=o(`sqlite3_result_blob`,``,[`number`,`number`,`number`,`number`]),fe=o(`sqlite3_result_int`,``,[`number`,`number`]),F=o(`sqlite3_result_error`,``,[`number`,`string`,`number`]),pe=o(`sqlite3_aggregate_context`,`number`,[`number`,`number`]),me=o(`RegisterExtensionFunctions`,`number`,[`number`]),he=o(`sqlite3_update_hook`,`number`,[`number`,`number`,`number`]);n.prototype.bind=function(e){if(!this.Qa)throw`Statement closed`;return this.reset(),Array.isArray(e)?this.Gb(e):typeof e==`object`&&e?this.Hb(e):!0},n.prototype.step=function(){if(!this.Qa)throw`Statement closed`;this.Oa=1;var e=b(this.Qa);switch(e){case 100:return!0;case 101:return!1;default:throw this.db.handleError(e)}},n.prototype.Ab=function(e){return e??(e=this.Oa,this.Oa+=1),w(this.Qa,e)},n.prototype.Ob=function(e){if(e??(e=this.Oa,this.Oa+=1),e=T(this.Qa,e),typeof BigInt!=`function`)throw Error(`BigInt is not supported`);return BigInt(e)},n.prototype.Tb=function(e){return e??(e=this.Oa,this.Oa+=1),T(this.Qa,e)},n.prototype.getBlob=function(e){e??(e=this.Oa,this.Oa+=1);var t=ne(this.Qa,e);e=E(this.Qa,e);for(var n=new Uint8Array(t),r=0;r<t;r+=1)n[r]=S[e+r];return n},n.prototype.get=function(e,t){t||={},e!=null&&this.bind(e)&&this.step(),e=[];for(var n=C(this.Qa),r=0;r<n;r+=1)switch(D(this.Qa,r)){case 1:var i=t.useBigInt?this.Ob(r):this.Ab(r);e.push(i);break;case 2:e.push(this.Ab(r));break;case 3:e.push(this.Tb(r));break;case 4:e.push(this.getBlob(r));break;default:e.push(null)}return e},n.prototype.qb=function(){for(var e=[],t=te(this.Qa),n=0;n<t;n+=1)e.push(O(this.Qa,n));return e},n.prototype.zb=function(e,t){e=this.get(e,t),t=this.qb();for(var n={},r=0;r<t.length;r+=1)n[t[r]]=e[r];return n},n.prototype.Sb=function(){return p(this.Qa)},n.prototype.Pb=function(){return ee(this.Qa)},n.prototype.run=function(e){return e!=null&&this.bind(e),this.step(),this.reset()},n.prototype.wb=function(e,t){t??(t=this.Oa,this.Oa+=1),e=wt(e),this.mb.push(e),this.db.handleError(h(this.Qa,t,e,-1,0))},n.prototype.Fb=function(e,t){t??(t=this.Oa,this.Oa+=1);var n=jt(e.length);S.set(e,n),this.mb.push(n),this.db.handleError(g(this.Qa,t,n,e.length,0))},n.prototype.vb=function(e,t){t??(t=this.Oa,this.Oa+=1),this.db.handleError((e===(e|0)?v:_)(this.Qa,t,e))},n.prototype.Ib=function(e){e??(e=this.Oa,this.Oa+=1),g(this.Qa,e,0,0,0)},n.prototype.xb=function(e,t){switch(t??(t=this.Oa,this.Oa+=1),typeof e){case`string`:this.wb(e,t);return;case`number`:this.vb(e,t);return;case`bigint`:this.wb(e.toString(),t);return;case`boolean`:this.vb(e+0,t);return;case`object`:if(e===null){this.Ib(t);return}if(e.length!=null){this.Fb(e,t);return}}throw`Wrong API use : tried to bind a value of an unknown type (`+e+`).`},n.prototype.Hb=function(e){var t=this;return Object.keys(e).forEach(function(n){var r=y(t.Qa,n);r!==0&&t.xb(e[n],r)}),!0},n.prototype.Gb=function(e){for(var t=0;t<e.length;t+=1)this.xb(e[t],t+1);return!0},n.prototype.reset=function(){return this.freemem(),k(this.Qa)===0&&re(this.Qa)===0},n.prototype.freemem=function(){for(var e;(e=this.mb.pop())!==void 0;)Mt(e)},n.prototype.Ya=function(){this.freemem();var e=ie(this.Qa)===0;return delete this.db.gb[this.Qa],this.Qa=0,e},r.prototype.next=function(){if(this.fb===null)return{done:!0};if(this.$a!==null&&(this.$a.Ya(),this.$a=null),!this.db.db)throw this.ob(),Error(`Database closed`);var e=Lt(),t=It(4);P(a),P(t);try{this.db.handleError(m(this.db.db,this.lb,-1,a,t)),this.lb=N(t,`i32`);var r=N(a,`i32`);return r===0?(this.ob(),{done:!0}):(this.$a=new n(r,this.db),this.db.gb[r]=this.$a,{value:this.$a,done:!1})}catch(e){throw this.sb=I(this.lb),this.ob(),e}finally{Ft(e)}},r.prototype.ob=function(){Mt(this.fb),this.fb=null},r.prototype.Qb=function(){return this.sb===null?I(this.lb):this.sb},typeof Symbol==`function`&&typeof Symbol.iterator==`symbol`&&(r.prototype[Symbol.iterator]=function(){return this}),i.prototype.run=function(e,t){if(!this.db)throw`Database closed`;if(t){e=this.tb(e,t);try{e.step()}finally{e.Ya()}}else this.handleError(u(this.db,e,0,0,a));return this},i.prototype.exec=function(e,t,r){if(!this.db)throw`Database closed`;var i=null,o=null,s=null;try{s=o=wt(e);var c=It(4);for(e=[];N(s,`i8`)!==0;){P(a),P(c),this.handleError(m(this.db,s,-1,a,c));var l=N(a,`i32`);if(s=N(c,`i32`),l!==0){var u=null;for(i=new n(l,this),t!=null&&i.bind(t);i.step();)u===null&&(u={columns:i.qb(),values:[]},e.push(u)),u.values.push(i.get(null,r));i.Ya()}}return e}catch(e){throw i&&i.Ya(),e}finally{o&&Mt(o)}},i.prototype.Mb=function(e,t,n,r,i){typeof t==`function`&&(r=n,n=t,t=void 0),e=this.tb(e,t);try{for(;e.step();)n(e.zb(null,i))}finally{e.Ya()}if(typeof r==`function`)return r()},i.prototype.tb=function(e,t){if(P(a),this.handleError(f(this.db,e,-1,a,0)),e=N(a,`i32`),e===0)throw`Nothing to prepare`;var r=new n(e,this);return t!=null&&r.bind(t),this.gb[e]=r},i.prototype.Ub=function(e){return new r(e,this)},i.prototype.Nb=function(){Object.values(this.gb).forEach(function(e){e.Ya()}),Object.values(this.Sa).forEach(Q),this.Sa={},this.handleError(l(this.db));var e=ct(this.filename);return this.handleError(c(this.filename,a)),this.db=N(a,`i32`),me(this.db),e},i.prototype.close=function(){this.db!==null&&(Object.values(this.gb).forEach(function(e){e.Ya()}),Object.values(this.Sa).forEach(Q),this.Sa={},this.Za&&=(Q(this.Za),void 0),this.handleError(l(this.db)),Qe(`/`+this.filename),this.db=null)},i.prototype.handleError=function(e){if(e===0)return null;throw e=x(this.db),Error(e)},i.prototype.Rb=function(){return d(this.db)},i.prototype.Kb=function(n,r){Object.prototype.hasOwnProperty.call(this.Sa,n)&&(Q(this.Sa[n]),delete this.Sa[n]);var i=At(function(n,i,a){i=t(i,a);try{var o=r.apply(null,i)}catch(e){F(n,e,-1);return}e(n,o)},`viii`);return this.Sa[n]=i,this.handleError(A(this.db,n,r.length,1,0,i,0,0,0)),this},i.prototype.Jb=function(n,r){var i=r.init||function(){return null},a=r.finalize||function(e){return e},o=r.step;if(!o)throw`An aggregate function must have a step function in `+n;var s={};Object.hasOwnProperty.call(this.Sa,n)&&(Q(this.Sa[n]),delete this.Sa[n]),r=n+`__finalize`,Object.hasOwnProperty.call(this.Sa,r)&&(Q(this.Sa[r]),delete this.Sa[r]);var c=At(function(e,n,r){var a=pe(e,1);Object.hasOwnProperty.call(s,a)||(s[a]=i()),n=t(n,r),n=[s[a]].concat(n);try{s[a]=o.apply(null,n)}catch(t){delete s[a],F(e,t,-1)}},`viii`),l=At(function(t){var n=pe(t,1);try{var r=a(s[n])}catch(e){delete s[n],F(t,e,-1);return}e(t,r),delete s[n]},`vi`);return this.Sa[n]=c,this.Sa[r]=l,this.handleError(A(this.db,n,o.length-1,1,0,0,c,l,0)),this},i.prototype.Zb=function(e){return this.Za&&=(he(this.db,0,0),Q(this.Za),void 0),e?(this.Za=At(function(t,n,r,i,a){switch(n){case 18:t=`insert`;break;case 23:t=`update`;break;case 9:t=`delete`;break;default:throw`unknown operationCode in updateHook callback: `+n}if(r=I(r),i=I(i),a>2**53-1)throw`rowId too big to fit inside a Number`;e(t,r,i,Number(a))},`viiiij`),he(this.db,this.Za,0),this):this},n.prototype.bind=n.prototype.bind,n.prototype.step=n.prototype.step,n.prototype.get=n.prototype.get,n.prototype.getColumnNames=n.prototype.qb,n.prototype.getAsObject=n.prototype.zb,n.prototype.getSQL=n.prototype.Sb,n.prototype.getNormalizedSQL=n.prototype.Pb,n.prototype.run=n.prototype.run,n.prototype.reset=n.prototype.reset,n.prototype.freemem=n.prototype.freemem,n.prototype.free=n.prototype.Ya,r.prototype.next=r.prototype.next,r.prototype.getRemainingSQL=r.prototype.Qb,i.prototype.run=i.prototype.run,i.prototype.exec=i.prototype.exec,i.prototype.each=i.prototype.Mb,i.prototype.prepare=i.prototype.tb,i.prototype.iterateStatements=i.prototype.Ub,i.prototype.export=i.prototype.Nb,i.prototype.close=i.prototype.close,i.prototype.handleError=i.prototype.handleError,i.prototype.getRowsModified=i.prototype.Rb,i.prototype.create_function=i.prototype.Kb,i.prototype.create_aggregate=i.prototype.Jb,i.prototype.updateHook=i.prototype.Zb,s.Database=i};var d=`./this.program`,f=(e,t)=>{throw t},p=globalThis.document?.currentScript?.src;typeof __filename<`u`?p=__filename:l&&(p=self.location.href);var ee=``,m,h;if(u){var g=r();ee=__dirname+`/`,h=e=>(e=te(e)?new URL(e):e,g.readFileSync(e)),m=async e=>(e=te(e)?new URL(e):e,g.readFileSync(e,void 0)),1<process.argv.length&&(d=process.argv[1].replace(/\\/g,`/`)),process.argv.slice(2),t!==void 0&&(t.exports=s),f=(e,t)=>{throw process.exitCode=e,t}}else if(c||l){try{ee=new URL(`.`,p).href}catch{}l&&(h=e=>{var t=new XMLHttpRequest;return t.open(`GET`,e,!1),t.responseType=`arraybuffer`,t.send(null),new Uint8Array(t.response)}),m=async e=>{if(te(e))return new Promise((t,n)=>{var r=new XMLHttpRequest;r.open(`GET`,e,!0),r.responseType=`arraybuffer`,r.onload=()=>{r.status==200||r.status==0&&r.response?t(r.response):n(r.status)},r.onerror=n,r.send(null)});var t=await fetch(e,{credentials:`same-origin`});if(t.ok)return t.arrayBuffer();throw Error(t.status+` : `+t.url)}}var _=console.log.bind(console),v=console.error.bind(console),y,b=!1,x,te=e=>e.startsWith(`file://`),S,C,w,T,E,ne,D,O;function re(){var e=Rt.buffer;S=new Int8Array(e),w=new Int16Array(e),C=new Uint8Array(e),new Uint16Array(e),T=new Int32Array(e),E=new Uint32Array(e),ne=new Float32Array(e),D=new Float64Array(e),O=new BigInt64Array(e),new BigUint64Array(e)}function k(e){throw s.onAbort?.(e),e=`Aborted(`+e+`)`,v(e),b=!0,new WebAssembly.RuntimeError(e+`. Build with -sASSERTIONS for more info.`)}var ie;async function A(e){if(!y)try{var t=await m(e);return new Uint8Array(t)}catch{}if(e==ie&&y)e=new Uint8Array(y);else if(h)e=h(e);else throw`both async and sync fetching of the wasm failed`;return e}async function ae(e,t){try{var n=await A(e);return await WebAssembly.instantiate(n,t)}catch(e){v(`failed to asynchronously prepare wasm: ${e}`),k(e)}}async function oe(e){var t=ie;if(!y&&!te(t)&&!u)try{var n=fetch(t,{credentials:`same-origin`});return await WebAssembly.instantiateStreaming(n,e)}catch(e){v(`wasm streaming compile failed: ${e}`),v(`falling back to ArrayBuffer instantiation`)}return ae(t,e)}class se{name=`ExitStatus`;constructor(e){this.message=`Program terminated with exit(${e})`,this.status=e}}var ce=e=>{for(;0<e.length;)e.shift()(s)},le=[],ue=[],de=()=>{var e=s.preRun.shift();ue.push(e)},j=0,M=null;function N(e,t=`i8`){switch(t.endsWith(`*`)&&(t=`*`),t){case`i1`:return S[e];case`i8`:return S[e];case`i16`:return w[e>>1];case`i32`:return T[e>>2];case`i64`:return O[e>>3];case`float`:return ne[e>>2];case`double`:return D[e>>3];case`*`:return E[e>>2];default:k(`invalid type for getValue: ${t}`)}}var fe=!0;function P(e){var t=`i32`;switch(t.endsWith(`*`)&&(t=`*`),t){case`i1`:S[e]=0;break;case`i8`:S[e]=0;break;case`i16`:w[e>>1]=0;break;case`i32`:T[e>>2]=0;break;case`i64`:O[e>>3]=BigInt(0);break;case`float`:ne[e>>2]=0;break;case`double`:D[e>>3]=0;break;case`*`:E[e>>2]=0;break;default:k(`invalid type for setValue: ${t}`)}}var F=new TextDecoder,pe=(e,t,n,r)=>{if(n=t+n,r)return n;for(;e[t]&&!(t>=n);)++t;return t},I=(e,t,n)=>e?F.decode(C.subarray(e,pe(C,e,t,n))):``,me=(e,t)=>{for(var n=0,r=e.length-1;0<=r;r--){var i=e[r];i===`.`?e.splice(r,1):i===`..`?(e.splice(r,1),n++):n&&(e.splice(r,1),n--)}if(t)for(;n;n--)e.unshift(`..`);return e},L=e=>{var t=e.charAt(0)===`/`,n=e.slice(-1)===`/`;return(e=me(e.split(`/`).filter(e=>!!e),!t).join(`/`))||t||(e=`.`),e&&n&&(e+=`/`),(t?`/`:``)+e},he=e=>{var t=/^(\/?|)([\s\S]*?)((?:\.{1,2}|[^\/]+?|)(\.[^.\/]*|))(?:[\/]*)$/.exec(e).slice(1);return e=t[0],t=t[1],!e&&!t?`.`:(t&&=t.slice(0,-1),e+t)},ge=e=>e&&e.match(/([^\/]+|\/)\/*$/)[1],_e=()=>{if(u){var e=r();return t=>e.randomFillSync(t)}return e=>crypto.getRandomValues(e)},ve=e=>{(ve=_e())(e)},ye=(...e)=>{for(var t=``,n=!1,r=e.length-1;-1<=r&&!n;r--){if(n=0<=r?e[r]:`/`,typeof n!=`string`)throw TypeError(`Arguments to path.resolve must be strings`);if(!n)return``;t=n+`/`+t,n=n.charAt(0)===`/`}return t=me(t.split(`/`).filter(e=>!!e),!n).join(`/`),(n?`/`:``)+t||`.`},R=e=>{var t=pe(e,0);return F.decode(e.buffer?e.subarray(0,t):new Uint8Array(e.slice(0,t)))},be=[],z=e=>{for(var t=0,n=0;n<e.length;++n){var r=e.charCodeAt(n);127>=r?t++:2047>=r?t+=2:55296<=r&&57343>=r?(t+=4,++n):t+=3}return t},B=(e,t,n,r)=>{if(!(0<r))return 0;var i=n;r=n+r-1;for(var a=0;a<e.length;++a){var o=e.codePointAt(a);if(127>=o){if(n>=r)break;t[n++]=o}else if(2047>=o){if(n+1>=r)break;t[n++]=192|o>>6,t[n++]=128|o&63}else if(65535>=o){if(n+2>=r)break;t[n++]=224|o>>12,t[n++]=128|o>>6&63,t[n++]=128|o&63}else{if(n+3>=r)break;t[n++]=240|o>>18,t[n++]=128|o>>12&63,t[n++]=128|o>>6&63,t[n++]=128|o&63,a++}}return t[n]=0,n-i},xe=[];function Se(e,t){xe[e]={input:[],output:[],eb:t},Ge(e,Ce)}var Ce={open(e){var t=xe[e.node.rdev];if(!t)throw new K(43);e.tty=t,e.seekable=!1},close(e){e.tty.eb.fsync(e.tty)},fsync(e){e.tty.eb.fsync(e.tty)},read(e,t,n,r){if(!e.tty||!e.tty.eb.Bb)throw new K(60);for(var i=0,a=0;a<r;a++){try{var o=e.tty.eb.Bb(e.tty)}catch{throw new K(29)}if(o===void 0&&i===0)throw new K(6);if(o==null)break;i++,t[n+a]=o}return i&&(e.node.atime=Date.now()),i},write(e,t,n,r){if(!e.tty||!e.tty.eb.ub)throw new K(60);try{for(var i=0;i<r;i++)e.tty.eb.ub(e.tty,t[n+i])}catch{throw new K(29)}return r&&(e.node.mtime=e.node.ctime=Date.now()),i}},V={Bb(){a:{if(!be.length){var e=null;if(u){var t=Buffer.alloc(256),n=0,r=process.stdin.fd;try{n=g.readSync(r,t,0,256)}catch(e){if(e.toString().includes(`EOF`))n=0;else throw e}0<n&&(e=t.slice(0,n).toString(`utf-8`))}else globalThis.window?.prompt&&(e=window.prompt(`Input: `),e!==null&&(e+=`
`));if(!e){e=null;break a}t=Array(z(e)+1),e=B(e,t,0,t.length),t.length=e,be=t}e=be.shift()}return e},ub(e,t){t===null||t===10?(_(R(e.output)),e.output=[]):t!=0&&e.output.push(t)},fsync(e){0<e.output?.length&&(_(R(e.output)),e.output=[])},hc(){return{bc:25856,dc:5,ac:191,cc:35387,$b:[3,28,127,21,4,0,1,0,17,19,26,0,18,15,23,22,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]}},ic(){return 0},jc(){return[24,80]}},H={ub(e,t){t===null||t===10?(v(R(e.output)),e.output=[]):t!=0&&e.output.push(t)},fsync(e){0<e.output?.length&&(v(R(e.output)),e.output=[])}},U={Wa:null,Xa(){return U.createNode(null,`/`,16895,0)},createNode(e,t,n,r){if((n&61440)==24576||(n&61440)==4096)throw new K(63);return U.Wa||={dir:{node:{Ta:U.La.Ta,Ua:U.La.Ua,lookup:U.La.lookup,ib:U.La.ib,rename:U.La.rename,unlink:U.La.unlink,rmdir:U.La.rmdir,readdir:U.La.readdir,symlink:U.La.symlink},stream:{Va:U.Ma.Va}},file:{node:{Ta:U.La.Ta,Ua:U.La.Ua},stream:{Va:U.Ma.Va,read:U.Ma.read,write:U.Ma.write,jb:U.Ma.jb,kb:U.Ma.kb}},link:{node:{Ta:U.La.Ta,Ua:U.La.Ua,readlink:U.La.readlink},stream:{}},yb:{node:{Ta:U.La.Ta,Ua:U.La.Ua},stream:We}},n=Ie(e,t,n,r),J(n.mode)?(n.La=U.Wa.dir.node,n.Ma=U.Wa.dir.stream,n.Na={}):(n.mode&61440)==32768?(n.La=U.Wa.file.node,n.Ma=U.Wa.file.stream,n.Ra=0,n.Na=null):(n.mode&61440)==40960?(n.La=U.Wa.link.node,n.Ma=U.Wa.link.stream):(n.mode&61440)==8192&&(n.La=U.Wa.yb.node,n.Ma=U.Wa.yb.stream),n.atime=n.mtime=n.ctime=Date.now(),e&&(e.Na[t]=n,e.atime=e.mtime=e.ctime=n.atime),n},fc(e){return e.Na?e.Na.subarray?e.Na.subarray(0,e.Ra):new Uint8Array(e.Na):new Uint8Array},La:{Ta(e){var t={};return t.dev=(e.mode&61440)==8192?e.id:1,t.ino=e.id,t.mode=e.mode,t.nlink=1,t.uid=0,t.gid=0,t.rdev=e.rdev,J(e.mode)?t.size=4096:(e.mode&61440)==32768?t.size=e.Ra:(e.mode&61440)==40960?t.size=e.link.length:t.size=0,t.atime=new Date(e.atime),t.mtime=new Date(e.mtime),t.ctime=new Date(e.ctime),t.blksize=4096,t.blocks=Math.ceil(t.size/t.blksize),t},Ua(e,t){for(var n of[`mode`,`atime`,`mtime`,`ctime`])t[n]!=null&&(e[n]=t[n]);t.size!==void 0&&(t=t.size,e.Ra!=t&&(t==0?(e.Na=null,e.Ra=0):(n=e.Na,e.Na=new Uint8Array(t),n&&e.Na.set(n.subarray(0,Math.min(t,e.Ra))),e.Ra=t)))},lookup(){throw U.nb||(U.nb=new K(44),U.nb.stack=`<generic error, no stack>`),U.nb},ib(e,t,n,r){return U.createNode(e,t,n,r)},rename(e,t,n){try{var r=Fe(t,n)}catch{}if(r){if(J(e.mode))for(var i in r.Na)throw new K(55);Pe(r)}delete e.parent.Na[e.name],t.Na[n]=e,e.name=n,t.ctime=t.mtime=e.parent.ctime=e.parent.mtime=Date.now()},unlink(e,t){delete e.Na[t],e.ctime=e.mtime=Date.now()},rmdir(e,t){var n=Fe(e,t),r;for(r in n.Na)throw new K(55);delete e.Na[t],e.ctime=e.mtime=Date.now()},readdir(e){return[`.`,`..`,...Object.keys(e.Na)]},symlink(e,t,n){return e=U.createNode(e,t,41471,0),e.link=n,e},readlink(e){if((e.mode&61440)!=40960)throw new K(28);return e.link}},Ma:{read(e,t,n,r,i){var a=e.node.Na;if(i>=e.node.Ra)return 0;if(e=Math.min(e.node.Ra-i,r),8<e&&a.subarray)t.set(a.subarray(i,i+e),n);else for(r=0;r<e;r++)t[n+r]=a[i+r];return e},write(e,t,n,r,i,a){if(t.buffer===S.buffer&&(a=!1),!r)return 0;if(e=e.node,e.mtime=e.ctime=Date.now(),t.subarray&&(!e.Na||e.Na.subarray)){if(a)return e.Na=t.subarray(n,n+r),e.Ra=r;if(e.Ra===0&&i===0)return e.Na=t.slice(n,n+r),e.Ra=r;if(i+r<=e.Ra)return e.Na.set(t.subarray(n,n+r),i),r}a=i+r;var o=e.Na?e.Na.length:0;if(o>=a||(a=Math.max(a,o*(1048576>o?2:1.125)>>>0),o!=0&&(a=Math.max(a,256)),o=e.Na,e.Na=new Uint8Array(a),0<e.Ra&&e.Na.set(o.subarray(0,e.Ra),0)),e.Na.subarray&&t.subarray)e.Na.set(t.subarray(n,n+r),i);else for(a=0;a<r;a++)e.Na[i+a]=t[n+a];return e.Ra=Math.max(e.Ra,i+r),r},Va(e,t,n){if(n===1?t+=e.position:n===2&&(e.node.mode&61440)==32768&&(t+=e.node.Ra),0>t)throw new K(28);return t},jb(e,t,n,r,i){if((e.node.mode&61440)!=32768)throw new K(43);if(e=e.node.Na,i&2||!e||e.buffer!==S.buffer){i=!0,r=65536*Math.ceil(t/65536);var a=Nt(65536,r);if(a&&C.fill(0,a,a+r),r=a,!r)throw new K(48);e&&((0<n||n+t<e.length)&&(e=e.subarray?e.subarray(n,n+t):Array.prototype.slice.call(e,n,n+t)),S.set(e,r))}else i=!1,r=e.byteOffset;return{Xb:r,Eb:i}},kb(e,t,n,r){return U.Ma.write(e,t,0,r,n,!1),0}}},we=(e,t)=>{var n=0;return e&&(n|=365),t&&(n|=146),n},Te=null,Ee={},W=[],De=1,G=null,Oe=!1,ke=!0,K=class{name=`ErrnoError`;constructor(e){this.Pa=e}},Ae=class{hb={};node=null;get flags(){return this.hb.flags}set flags(e){this.hb.flags=e}get position(){return this.hb.position}set position(e){this.hb.position=e}},je=class{La={};Ma={};bb=null;constructor(e,t,n,r){e||=this,this.parent=e,this.Xa=e.Xa,this.id=De++,this.name=t,this.mode=n,this.rdev=r,this.atime=this.mtime=this.ctime=Date.now()}get read(){return(this.mode&365)==365}set read(e){e?this.mode|=365:this.mode&=-366}get write(){return(this.mode&146)==146}set write(e){e?this.mode|=146:this.mode&=-147}};function q(e,t={}){if(!e)throw new K(44);t.pb??=!0,e.charAt(0)===`/`||(e=`//`+e);var n=0;a:for(;40>n;n++){e=e.split(`/`).filter(e=>!!e);for(var r=Te,i=`/`,a=0;a<e.length;a++){var o=a===e.length-1;if(o&&t.parent)break;if(e[a]!==`.`)if(e[a]===`..`)if(i=he(i),r===r.parent){e=i+`/`+e.slice(a+1).join(`/`),n--;continue a}else r=r.parent;else{i=L(i+`/`+e[a]);try{r=Fe(r,e[a])}catch(e){if(e?.Pa===44&&o&&t.Wb)return{path:i};throw e}if(!r.bb||o&&!t.pb||(r=r.bb.root),(r.mode&61440)==40960&&(!o||t.ab)){if(!r.La.readlink)throw new K(52);r=r.La.readlink(r),r.charAt(0)===`/`||(r=he(i)+`/`+r),e=r+`/`+e.slice(a+1).join(`/`);continue a}}}return{path:i,node:r}}throw new K(32)}function Me(e){for(var t;;){if(e===e.parent)return e=e.Xa.Db,t?e[e.length-1]===`/`?e+t:`${e}/${t}`:e;t=t?`${e.name}/${t}`:e.name,e=e.parent}}function Ne(e,t){for(var n=0,r=0;r<t.length;r++)n=(n<<5)-n+t.charCodeAt(r)|0;return(e+n>>>0)%G.length}function Pe(e){var t=Ne(e.parent.id,e.name);if(G[t]===e)G[t]=e.cb;else for(t=G[t];t;){if(t.cb===e){t.cb=e.cb;break}t=t.cb}}function Fe(e,t){var n=J(e.mode)?(n=Le(e,`x`))?n:e.La.lookup?0:2:54;if(n)throw new K(n);for(n=G[Ne(e.id,t)];n;n=n.cb){var r=n.name;if(n.parent.id===e.id&&r===t)return n}return e.La.lookup(e,t)}function Ie(e,t,n,r){return e=new je(e,t,n,r),t=Ne(e.parent.id,e.name),e.cb=G[t],G[t]=e}function J(e){return(e&61440)==16384}function Le(e,t){return ke?0:t.includes(`r`)&&!(e.mode&292)||t.includes(`w`)&&!(e.mode&146)||t.includes(`x`)&&!(e.mode&73)?2:0}function Re(e,t){if(!J(e.mode))return 54;try{return Fe(e,t),20}catch{}return Le(e,`wx`)}function ze(e,t,n){try{var r=Fe(e,t)}catch(e){return e.Pa}if(e=Le(e,`wx`))return e;if(n){if(!J(r.mode))return 54;if(r===r.parent||Me(r)===`/`)return 10}else if(J(r.mode))return 31;return 0}function Be(e){if(!e)throw new K(63);return e}function Y(e){if(e=W[e],!e)throw new K(8);return e}function Ve(e,t=-1){if(e=Object.assign(new Ae,e),t==-1)a:{for(t=0;4096>=t;t++)if(!W[t])break a;throw new K(33)}return e.fd=t,W[t]=e}function He(e,t=-1){return e=Ve(e,t),e.Ma?.ec?.(e),e}function Ue(e,t,n){var r=e?.Ma.Ua;e=r?e:t,r??=t.La.Ua,Be(r),r(e,n)}var We={open(e){e.Ma=Ee[e.node.rdev].Ma,e.Ma.open?.(e)},Va(){throw new K(70)}};function Ge(e,t){Ee[e]={Ma:t}}function Ke(e,t){var n=t===`/`;if(n&&Te)throw new K(10);if(!n&&t){var r=q(t,{pb:!1});if(t=r.path,r=r.node,r.bb)throw new K(10);if(!J(r.mode))throw new K(54)}t={type:e,kc:{},Db:t,Vb:[]},e=e.Xa(t),e.Xa=t,t.root=e,n?Te=e:r&&(r.bb=t,r.Xa&&r.Xa.Vb.push(t))}function qe(e,t,n){var r=q(e,{parent:!0}).node;if(e=ge(e),!e)throw new K(28);if(e===`.`||e===`..`)throw new K(20);var i=Re(r,e);if(i)throw new K(i);if(!r.La.ib)throw new K(63);return r.La.ib(r,e,t,n)}function Je(e,t=438){return qe(e,t&4095|32768,0)}function X(e,t=511){return qe(e,t&1023|16384,0)}function Ye(e,t,n){n===void 0&&(n=t,t=438),qe(e,t|8192,n)}function Xe(e,t){if(!ye(e))throw new K(44);var n=q(t,{parent:!0}).node;if(!n)throw new K(44);t=ge(t);var r=Re(n,t);if(r)throw new K(r);if(!n.La.symlink)throw new K(63);n.La.symlink(n,t,e)}function Ze(e){var t=q(e,{parent:!0}).node;e=ge(e);var n=Fe(t,e),r=ze(t,e,!0);if(r)throw new K(r);if(!t.La.rmdir)throw new K(63);if(n.bb)throw new K(10);t.La.rmdir(t,e),Pe(n)}function Qe(e){var t=q(e,{parent:!0}).node;if(!t)throw new K(44);e=ge(e);var n=Fe(t,e),r=ze(t,e,!1);if(r)throw new K(r);if(!t.La.unlink)throw new K(63);if(n.bb)throw new K(10);t.La.unlink(t,e),Pe(n)}function $e(e,t){return e=q(e,{ab:!t}).node,Be(e.La.Ta)(e)}function et(e,t,n,r){Ue(e,t,{mode:n&4095|t.mode&-4096,ctime:Date.now(),Lb:r})}function tt(e,t){e=typeof e==`string`?q(e,{ab:!0}).node:e,et(null,e,t)}function nt(e,t,n){if(J(t.mode))throw new K(31);if((t.mode&61440)!=32768)throw new K(28);var r=Le(t,`w`);if(r)throw new K(r);Ue(e,t,{size:n,timestamp:Date.now()})}function rt(e,t,n=438){if(e===``)throw new K(44);if(typeof t==`string`){var r={r:0,"r+":2,w:577,"w+":578,a:1089,"a+":1090}[t];if(r===void 0)throw Error(`Unknown file open mode: ${t}`);t=r}if(n=t&64?n&4095|32768:0,typeof e==`object`)r=e;else{var i=e.endsWith(`/`),a=q(e,{ab:!(t&131072),Wb:!0});r=a.node,e=a.path}if(a=!1,t&64)if(r){if(t&128)throw new K(20)}else{if(i)throw new K(31);r=qe(e,n|511,0),a=!0}if(!r)throw new K(44);if((r.mode&61440)==8192&&(t&=-513),t&65536&&!J(r.mode))throw new K(54);if(!a&&(r?(r.mode&61440)==40960?i=32:(i=[`r`,`w`,`rw`][t&3],t&512&&(i+=`w`),i=J(r.mode)&&(i!==`r`||t&576)?31:Le(r,i)):i=44,i))throw new K(i);return t&512&&!a&&(i=r,i=typeof i==`string`?q(i,{ab:!0}).node:i,nt(null,i,0)),t=Ve({node:r,path:Me(r),flags:t&-131713,seekable:!0,position:0,Ma:r.Ma,Yb:[],error:!1}),t.Ma.open&&t.Ma.open(t),a&&tt(r,n&511),t}function it(e){if(e.fd===null)throw new K(8);e.rb&&=null;try{e.Ma.close&&e.Ma.close(e)}catch(e){throw e}finally{W[e.fd]=null}e.fd=null}function at(e,t,n){if(e.fd===null)throw new K(8);if(!e.seekable||!e.Ma.Va)throw new K(70);if(n!=0&&n!=1&&n!=2)throw new K(28);e.position=e.Ma.Va(e,t,n),e.Yb=[]}function ot(e,t,n,r,i){if(0>r||0>i)throw new K(28);if(e.fd===null||(e.flags&2097155)==1)throw new K(8);if(J(e.node.mode))throw new K(31);if(!e.Ma.read)throw new K(28);var a=i!==void 0;if(!a)i=e.position;else if(!e.seekable)throw new K(70);return t=e.Ma.read(e,t,n,r,i),a||(e.position+=t),t}function st(e,t,n,r,i){if(0>r||0>i)throw new K(28);if(e.fd===null||!(e.flags&2097155))throw new K(8);if(J(e.node.mode))throw new K(31);if(!e.Ma.write)throw new K(28);e.seekable&&e.flags&1024&&at(e,0,2);var a=i!==void 0;if(!a)i=e.position;else if(!e.seekable)throw new K(70);return t=e.Ma.write(e,t,n,r,i,void 0),a||(e.position+=t),t}function ct(e){var t=t||0,n=`binary`;n!==`utf8`&&n!==`binary`&&k(`Invalid encoding type "${n}"`),t=rt(e,t),e=$e(e).size;var r=new Uint8Array(e);return ot(t,r,0,e,0),n===`utf8`&&(r=R(r)),it(t),r}function lt(e,t,n){e=L(`/dev/`+e);var r=we(!!t,!!n);lt.Cb??=64;var i=lt.Cb++<<8|0;Ge(i,{open(e){e.seekable=!1},close(){n?.buffer?.length&&n(10)},read(e,n,r,i){for(var a=0,o=0;o<i;o++){try{var s=t()}catch{throw new K(29)}if(s===void 0&&a===0)throw new K(6);if(s==null)break;a++,n[r+o]=s}return a&&(e.node.atime=Date.now()),a},write(e,t,r,i){for(var a=0;a<i;a++)try{n(t[r+a])}catch{throw new K(29)}return i&&(e.node.mtime=e.node.ctime=Date.now()),a}}),Ye(e,r,i)}var Z={};function ut(e,t,n){if(t.charAt(0)===`/`)return t;if(e=e===-100?`/`:Y(e).path,t.length==0){if(!n)throw new K(44);return e}return e+`/`+t}function dt(e,t){E[e>>2]=t.dev,E[e+4>>2]=t.mode,E[e+8>>2]=t.nlink,E[e+12>>2]=t.uid,E[e+16>>2]=t.gid,E[e+20>>2]=t.rdev,O[e+24>>3]=BigInt(t.size),T[e+32>>2]=4096,T[e+36>>2]=t.blocks;var n=t.atime.getTime(),r=t.mtime.getTime(),i=t.ctime.getTime();return O[e+40>>3]=BigInt(Math.floor(n/1e3)),E[e+48>>2]=n%1e3*1e6,O[e+56>>3]=BigInt(Math.floor(r/1e3)),E[e+64>>2]=r%1e3*1e6,O[e+72>>3]=BigInt(Math.floor(i/1e3)),E[e+80>>2]=i%1e3*1e6,O[e+88>>3]=BigInt(t.ino),0}var ft=void 0,pt=()=>{var e=T[ft>>2];return ft+=4,e},mt=0,ht=[0,31,60,91,121,152,182,213,244,274,305,335],gt=[0,31,59,90,120,151,181,212,243,273,304,334],_t={},vt=e=>{x=e,fe||0<mt||(s.onExit?.(e),b=!0),f(e,new se(e))},yt=e=>{if(!b)try{e()}catch(e){e instanceof se||e==`unwind`||f(1,e)}finally{if(!(fe||0<mt))try{x=e=x,vt(e)}catch(e){e instanceof se||e==`unwind`||f(1,e)}}},bt={},xt=()=>{if(!St){var e={USER:`web_user`,LOGNAME:`web_user`,PATH:`/`,PWD:`/`,HOME:`/home/web_user`,LANG:(globalThis.navigator?.language??`C`).replace(`-`,`_`)+`.UTF-8`,_:d||`./this.program`},t;for(t in bt)bt[t]===void 0?delete e[t]:e[t]=bt[t];var n=[];for(t in e)n.push(`${t}=${e[t]}`);St=n}return St},St,Ct=(e,t,n,r)=>{var i={string:e=>{var t=0;if(e!=null&&e!==0){t=z(e)+1;var n=It(t);B(e,C,n,t),t=n}return t},array:e=>{var t=It(e.length);return S.set(e,t),t}};e=s[`_`+e];var a=[],o=0;if(r)for(var c=0;c<r.length;c++){var l=i[n[c]];l?(o===0&&(o=Lt()),a[c]=l(r[c])):a[c]=r[c]}return n=e(...a),n=function(e){return o!==0&&Ft(o),t===`string`?I(e):t===`boolean`?!!e:e}(n)},wt=e=>{var t=z(e)+1,n=jt(t);return n&&B(e,C,n,t),n},Tt,Et=[],Q=e=>{Tt.delete($.get(e)),$.set(e,null),Et.push(e)},Dt=e=>{let t=e.length;return[t%128|128,t>>7,...e]},Ot={i:127,p:127,j:126,f:125,d:124,e:111},kt=e=>Dt(Array.from(e,e=>Ot[e])),At=(e,t)=>{if(!Tt){Tt=new WeakMap;var n=$.length;if(Tt)for(var r=0;r<0+n;r++){var i=$.get(r);i&&Tt.set(i,r)}}if(n=Tt.get(e)||0)return n;n=Et.length?Et.pop():$.grow(1);try{$.set(n,e)}catch(r){if(!(r instanceof TypeError))throw r;t=Uint8Array.of(0,97,115,109,1,0,0,0,1,...Dt([1,96,...kt(t.slice(1)),...kt(t[0]===`v`?``:t[0])]),2,7,1,1,101,1,102,0,0,7,5,1,1,102,0,0),t=new WebAssembly.Module(t),t=new WebAssembly.Instance(t,{e:{f:e}}).exports.f,$.set(n,t)}return Tt.set(e,n),n};if(G=Array(4096),Ke(U,`/`),X(`/tmp`),X(`/home`),X(`/home/web_user`),(function(){X(`/dev`),Ge(259,{read:()=>0,write:(e,t,n,r)=>r,Va:()=>0}),Ye(`/dev/null`,259),Se(1280,V),Se(1536,H),Ye(`/dev/tty`,1280),Ye(`/dev/tty1`,1536);var e=new Uint8Array(1024),t=0,n=()=>(t===0&&(ve(e),t=e.byteLength),e[--t]);lt(`random`,n),lt(`urandom`,n),X(`/dev/shm`),X(`/dev/shm/tmp`)})(),(function(){X(`/proc`);var e=X(`/proc/self`);X(`/proc/self/fd`),Ke({Xa(){var t=Ie(e,`fd`,16895,73);return t.Ma={Va:U.Ma.Va},t.La={lookup(e,t){e=+t;var n=Y(e);return e={parent:null,Xa:{Db:`fake`},La:{readlink:()=>n.path},id:e+1},e.parent=e},readdir(){return Array.from(W.entries()).filter(([,e])=>e).map(([e])=>e.toString())}},t}},`/proc/self/fd`)})(),s.noExitRuntime&&(fe=s.noExitRuntime),s.print&&(_=s.print),s.printErr&&(v=s.printErr),s.wasmBinary&&(y=s.wasmBinary),s.thisProgram&&(d=s.thisProgram),s.preInit)for(typeof s.preInit==`function`&&(s.preInit=[s.preInit]);0<s.preInit.length;)s.preInit.shift()();s.stackSave=()=>Lt(),s.stackRestore=e=>Ft(e),s.stackAlloc=e=>It(e),s.cwrap=(e,t,n,r)=>{var i=!n||n.every(e=>e===`number`||e===`boolean`);return t!==`string`&&i&&!r?s[`_`+e]:(...r)=>Ct(e,t,n,r)},s.addFunction=At,s.removeFunction=Q,s.UTF8ToString=I,s.stringToNewUTF8=wt,s.writeArrayToMemory=(e,t)=>{S.set(e,t)};var jt,Mt,Nt,Pt,Ft,It,Lt,Rt,$,zt={a:(e,t,n,r)=>k(`Assertion failed: ${I(e)}, at: `+[t?I(t):`unknown filename`,n,r?I(r):`unknown function`]),i:function(e,t){try{return e=I(e),tt(e,t),0}catch(e){if(Z===void 0||e.name!==`ErrnoError`)throw e;return-e.Pa}},L:function(e,t,n){try{if(t=I(t),t=ut(e,t),n&-8)return-28;var r=q(t,{ab:!0}).node;return r?(e=``,n&4&&(e+=`r`),n&2&&(e+=`w`),n&1&&(e+=`x`),e&&Le(r,e)?-2:0):-44}catch(e){if(Z===void 0||e.name!==`ErrnoError`)throw e;return-e.Pa}},j:function(e,t){try{var n=Y(e);return et(n,n.node,t,!1),0}catch(e){if(Z===void 0||e.name!==`ErrnoError`)throw e;return-e.Pa}},h:function(e){try{var t=Y(e);return Ue(t,t.node,{timestamp:Date.now(),Lb:!1}),0}catch(e){if(Z===void 0||e.name!==`ErrnoError`)throw e;return-e.Pa}},b:function(e,t,n){ft=n;try{var r=Y(e);switch(t){case 0:var i=pt();if(0>i)break;for(;W[i];)i++;return He(r,i).fd;case 1:case 2:return 0;case 3:return r.flags;case 4:return i=pt(),r.flags|=i,0;case 12:return i=pt(),w[i+0>>1]=2,0;case 13:case 14:return 0}return-28}catch(e){if(Z===void 0||e.name!==`ErrnoError`)throw e;return-e.Pa}},g:function(e,t){try{var n=Y(e),r=n.node,i=n.Ma.Ta;return e=i?n:r,i??=r.La.Ta,Be(i),dt(t,i(e))}catch(e){if(Z===void 0||e.name!==`ErrnoError`)throw e;return-e.Pa}},H:function(e,t){t=-9007199254740992>t||9007199254740992<t?NaN:Number(t);try{if(isNaN(t))return-61;var n=Y(e);if(0>t||!(n.flags&2097155))throw new K(28);return nt(n,n.node,t),0}catch(e){if(Z===void 0||e.name!==`ErrnoError`)throw e;return-e.Pa}},G:function(e,t){try{if(t===0)return-28;var n=z(`/`)+1;return t<n?-68:(B(`/`,C,e,t),n)}catch(e){if(Z===void 0||e.name!==`ErrnoError`)throw e;return-e.Pa}},K:function(e,t){try{return e=I(e),dt(t,$e(e,!0))}catch(e){if(Z===void 0||e.name!==`ErrnoError`)throw e;return-e.Pa}},C:function(e,t,n){try{return t=I(t),t=ut(e,t),X(t,n),0}catch(e){if(Z===void 0||e.name!==`ErrnoError`)throw e;return-e.Pa}},J:function(e,t,n,r){try{t=I(t);var i=r&256;return t=ut(e,t,r&4096),dt(n,i?$e(t,!0):$e(t))}catch(e){if(Z===void 0||e.name!==`ErrnoError`)throw e;return-e.Pa}},x:function(e,t,n,r){ft=r;try{t=I(t),t=ut(e,t);var i=r?pt():0;return rt(t,n,i).fd}catch(e){if(Z===void 0||e.name!==`ErrnoError`)throw e;return-e.Pa}},v:function(e,t,n,r){try{if(t=I(t),t=ut(e,t),0>=r)return-28;var i=q(t).node;if(!i)throw new K(44);if(!i.La.readlink)throw new K(28);var a=i.La.readlink(i),o=Math.min(r,z(a)),s=S[n+o];return B(a,C,n,r+1),S[n+o]=s,o}catch(e){if(Z===void 0||e.name!==`ErrnoError`)throw e;return-e.Pa}},u:function(e){try{return e=I(e),Ze(e),0}catch(e){if(Z===void 0||e.name!==`ErrnoError`)throw e;return-e.Pa}},f:function(e,t){try{return e=I(e),dt(t,$e(e))}catch(e){if(Z===void 0||e.name!==`ErrnoError`)throw e;return-e.Pa}},r:function(e,t,n){try{if(t=I(t),t=ut(e,t),n)if(n===512)Ze(t);else return-28;else Qe(t);return 0}catch(e){if(Z===void 0||e.name!==`ErrnoError`)throw e;return-e.Pa}},q:function(e,t,n){try{t=I(t),t=ut(e,t,!0);var r=Date.now(),i,a;if(n){var o=E[n>>2]+4294967296*T[n+4>>2],s=T[n+8>>2];i=s==1073741823?r:s==1073741822?null:1e3*o+s/1e6,n+=16,o=E[n>>2]+4294967296*T[n+4>>2],s=T[n+8>>2],a=s==1073741823?r:s==1073741822?null:1e3*o+s/1e6}else a=i=r;if((a??i)!==null){e=i;var c=q(t,{ab:!0}).node;Be(c.La.Ua)(c,{atime:e,mtime:a})}return 0}catch(e){if(Z===void 0||e.name!==`ErrnoError`)throw e;return-e.Pa}},m:()=>k(``),l:()=>{fe=!1,mt=0},A:function(e,t){e=-9007199254740992>e||9007199254740992<e?NaN:Number(e),e=new Date(1e3*e),T[t>>2]=e.getSeconds(),T[t+4>>2]=e.getMinutes(),T[t+8>>2]=e.getHours(),T[t+12>>2]=e.getDate(),T[t+16>>2]=e.getMonth(),T[t+20>>2]=e.getFullYear()-1900,T[t+24>>2]=e.getDay();var n=e.getFullYear();T[t+28>>2]=(n%4!=0||n%100==0&&n%400!=0?gt:ht)[e.getMonth()]+e.getDate()-1|0,T[t+36>>2]=-(60*e.getTimezoneOffset()),n=new Date(e.getFullYear(),6,1).getTimezoneOffset();var r=new Date(e.getFullYear(),0,1).getTimezoneOffset();T[t+32>>2]=(n!=r&&e.getTimezoneOffset()==Math.min(r,n))|0},y:function(e,t,n,r,i,a,o){i=-9007199254740992>i||9007199254740992<i?NaN:Number(i);try{var s=Y(r);if(t&2&&!(n&2)&&(s.flags&2097155)!=2||(s.flags&2097155)==1)throw new K(2);if(!s.Ma.jb)throw new K(43);if(!e)throw new K(28);var c=s.Ma.jb(s,e,i,t,n),l=c.Xb;return T[a>>2]=c.Eb,E[o>>2]=l,0}catch(e){if(Z===void 0||e.name!==`ErrnoError`)throw e;return-e.Pa}},z:function(e,t,n,r,i,a){a=-9007199254740992>a||9007199254740992<a?NaN:Number(a);try{var o=Y(i);if(n&2){if(n=a,(o.node.mode&61440)!=32768)throw new K(43);if(!(r&2)){var s=C.slice(e,e+t);o.Ma.kb&&o.Ma.kb(o,s,n,t,r)}}}catch(e){if(Z===void 0||e.name!==`ErrnoError`)throw e;return-e.Pa}},n:(e,t)=>(_t[e]&&(clearTimeout(_t[e].id),delete _t[e]),t&&(_t[e]={id:setTimeout(()=>{delete _t[e],yt(()=>Pt(e,performance.now()))},t),lc:t}),0),B:(e,t,n,r)=>{var i=new Date().getFullYear(),a=new Date(i,0,1).getTimezoneOffset();i=new Date(i,6,1).getTimezoneOffset(),E[e>>2]=60*Math.max(a,i),T[t>>2]=Number(a!=i),t=e=>{var t=Math.abs(e);return`UTC${0<=e?`-`:`+`}${String(Math.floor(t/60)).padStart(2,`0`)}${String(t%60).padStart(2,`0`)}`},e=t(a),t=t(i),i<a?(B(e,C,n,17),B(t,C,r,17)):(B(e,C,r,17),B(t,C,n,17))},d:()=>Date.now(),s:()=>2147483648,c:()=>performance.now(),o:e=>{var t=C.length;if(e>>>=0,2147483648<e)return!1;for(var n=1;4>=n;n*=2){var r=t*(1+.2/n);r=Math.min(r,e+100663296);a:{r=(Math.min(2147483648,65536*Math.ceil(Math.max(e,r)/65536))-Rt.buffer.byteLength+65535)/65536|0;try{Rt.grow(r),re();var i=1;break a}catch{}i=void 0}if(i)return!0}return!1},E:(e,t)=>{var n=0,r=0,i;for(i of xt()){var a=t+n;E[e+r>>2]=a,n+=B(i,C,a,1/0)+1,r+=4}return 0},F:(e,t)=>{var n=xt();E[e>>2]=n.length,e=0;for(var r of n)e+=z(r)+1;return E[t>>2]=e,0},e:function(e){try{return it(Y(e)),0}catch(e){if(Z===void 0||e.name!==`ErrnoError`)throw e;return e.Pa}},p:function(e,t){try{var n=Y(e);return S[t]=n.tty?2:J(n.mode)?3:(n.mode&61440)==40960?7:4,w[t+2>>1]=0,O[t+8>>3]=BigInt(0),O[t+16>>3]=BigInt(0),0}catch(e){if(Z===void 0||e.name!==`ErrnoError`)throw e;return e.Pa}},w:function(e,t,n,r){try{a:{var i=Y(e);e=t;for(var a,o=t=0;o<n;o++){var s=E[e>>2],c=E[e+4>>2];e+=8;var l=ot(i,S,s,c,a);if(0>l){var u=-1;break a}if(t+=l,l<c)break;a!==void 0&&(a+=l)}u=t}return E[r>>2]=u,0}catch(e){if(Z===void 0||e.name!==`ErrnoError`)throw e;return e.Pa}},D:function(e,t,n,r){t=-9007199254740992>t||9007199254740992<t?NaN:Number(t);try{if(isNaN(t))return 61;var i=Y(e);return at(i,t,n),O[r>>3]=BigInt(i.position),i.rb&&t===0&&n===0&&(i.rb=null),0}catch(e){if(Z===void 0||e.name!==`ErrnoError`)throw e;return e.Pa}},I:function(e){try{var t=Y(e);return t.Ma?.fsync?.(t)}catch(e){if(Z===void 0||e.name!==`ErrnoError`)throw e;return e.Pa}},t:function(e,t,n,r){try{a:{var i=Y(e);e=t;for(var a,o=t=0;o<n;o++){var s=E[e>>2],c=E[e+4>>2];e+=8;var l=st(i,S,s,c,a);if(0>l){var u=-1;break a}if(t+=l,l<c)break;a!==void 0&&(a+=l)}u=t}return E[r>>2]=u,0}catch(e){if(Z===void 0||e.name!==`ErrnoError`)throw e;return e.Pa}},k:vt};function Bt(){function e(){if(s.calledRun=!0,!b){if(!s.noFSInit&&!Oe){var e,t;Oe=!0,e??=s.stdin,t??=s.stdout,n??=s.stderr,e?lt(`stdin`,e):Xe(`/dev/tty`,`/dev/stdin`),t?lt(`stdout`,null,t):Xe(`/dev/tty`,`/dev/stdout`),n?lt(`stderr`,null,n):Xe(`/dev/tty1`,`/dev/stderr`),rt(`/dev/stdin`,0),rt(`/dev/stdout`,1),rt(`/dev/stderr`,1)}if(Vt.N(),ke=!1,s.onRuntimeInitialized?.(),s.postRun)for(typeof s.postRun==`function`&&(s.postRun=[s.postRun]);s.postRun.length;){var n=s.postRun.shift();le.push(n)}ce(le)}}if(0<j)M=Bt;else{if(s.preRun)for(typeof s.preRun==`function`&&(s.preRun=[s.preRun]);s.preRun.length;)de();ce(ue),0<j?M=Bt:s.setStatus?(s.setStatus(`Running...`),setTimeout(()=>{setTimeout(()=>s.setStatus(``),1),e()},1)):e()}}var Vt;return(async function(){function e(e){return e=Vt=e.exports,s._sqlite3_free=e.P,s._sqlite3_value_text=e.Q,s._sqlite3_prepare_v2=e.R,s._sqlite3_step=e.S,s._sqlite3_reset=e.T,s._sqlite3_exec=e.U,s._sqlite3_finalize=e.V,s._sqlite3_column_name=e.W,s._sqlite3_column_text=e.X,s._sqlite3_column_type=e.Y,s._sqlite3_errmsg=e.Z,s._sqlite3_clear_bindings=e._,s._sqlite3_value_blob=e.$,s._sqlite3_value_bytes=e.aa,s._sqlite3_value_double=e.ba,s._sqlite3_value_int=e.ca,s._sqlite3_value_type=e.da,s._sqlite3_result_blob=e.ea,s._sqlite3_result_double=e.fa,s._sqlite3_result_error=e.ga,s._sqlite3_result_int=e.ha,s._sqlite3_result_int64=e.ia,s._sqlite3_result_null=e.ja,s._sqlite3_result_text=e.ka,s._sqlite3_aggregate_context=e.la,s._sqlite3_column_count=e.ma,s._sqlite3_data_count=e.na,s._sqlite3_column_blob=e.oa,s._sqlite3_column_bytes=e.pa,s._sqlite3_column_double=e.qa,s._sqlite3_bind_blob=e.ra,s._sqlite3_bind_double=e.sa,s._sqlite3_bind_int=e.ta,s._sqlite3_bind_text=e.ua,s._sqlite3_bind_parameter_index=e.va,s._sqlite3_sql=e.wa,s._sqlite3_normalized_sql=e.xa,s._sqlite3_changes=e.ya,s._sqlite3_close_v2=e.za,s._sqlite3_create_function_v2=e.Aa,s._sqlite3_update_hook=e.Ba,s._sqlite3_open=e.Ca,jt=s._malloc=e.Da,Mt=s._free=e.Ea,s._RegisterExtensionFunctions=e.Fa,Nt=e.Ga,Pt=e.Ha,Ft=e.Ia,It=e.Ja,Lt=e.Ka,Rt=e.M,$=e.O,re(),j--,s.monitorRunDependencies?.(j),j==0&&M&&(e=M,M=null,e()),Vt}j++,s.monitorRunDependencies?.(j);var t={a:zt};return s.instantiateWasm?new Promise(n=>{s.instantiateWasm(t,(t,r)=>{n(e(t,r))})}):(ie??=s.locateFile?s.locateFile(`sql-wasm.wasm`,ee):ee+`sql-wasm.wasm`,e((await oe(t)).instance))})(),Bt(),a}),n)};typeof e==`object`&&typeof t==`object`?(t.exports=i,t.exports.default=i):typeof define==`function`&&define.amd?define([],function(){return i}):typeof e==`object`&&(e.Module=i)}))(),1),a=`/assets/sql-wasm-UFUCzYNW.wasm`,o=t({LocalDatabaseManager:()=>Me,LocalDbIntegrityError:()=>E,bulkUpsertRows:()=>he,clearLocalDatabase:()=>M,createAndRetainBackup:()=>K,createBackupSnapshot:()=>De,decryptData:()=>V,deleteRow:()=>me,encryptData:()=>Ce,enqueueOutbox:()=>xe,extractUpdatedAt:()=>B,getAutoBackupSnapshot:()=>je,getDb:()=>N,getMetaValue:()=>oe,getOrCreateMasterKey:()=>H,getOrCreateSigningKey:()=>we,getPendingOutbox:()=>z,initLocalDb:()=>j,isRowSoftDeleted:()=>_e,listAutoBackups:()=>Ae,loadEncryptedAttachment:()=>W,markOutboxStatus:()=>Se,openIndexedDbForDeviceId:()=>S,purgeSoftDeletedRow:()=>ye,queryTable:()=>be,restoreFromBackupSnapshot:()=>G,rotateMasterKey:()=>Te,runIntegrityCheck:()=>le,runLocal:()=>F,saveEncryptedAttachment:()=>Ee,selectAll:()=>pe,selectAllLive:()=>R,selectById:()=>I,setMetaValue:()=>se,sha256Hex:()=>C,softDeleteRow:()=>ge,undeleteRow:()=>ve,upsertRow:()=>L,verifyBackupRestorable:()=>Oe}),s=`mtj_erp_local_db`,c=4,l=`mtj_erp_crypto_key`,u=`local-data-key`,d=`local-signing-key`;function f(){return window.mtjDesktop?.secureStore??null}function p(e){let t=``;for(let n of e)t+=String.fromCharCode(n);return btoa(t)}function ee(e){return Uint8Array.from(atob(e),e=>e.charCodeAt(0))}async function m(e,t){await new Promise((n,r)=>{let i=e.transaction(`crypto`,`readwrite`).objectStore(`crypto`).delete(t);i.onsuccess=()=>n(),i.onerror=()=>r(i.error)})}var h=null,g=null,_=null;function v(e){return e==null?null:typeof e==`boolean`?+!!e:typeof e==`object`?JSON.stringify(e):e}function y(e){let t={};for(let[n,r]of Object.entries(e)){if(typeof r==`string`&&(n===`data`||n===`parsed`))try{t[n]=JSON.parse(r);continue}catch{}t[n]=r}return t}var b=null;function x(){return b||(b=new Promise((e,t)=>{let n=window.indexedDB.open(s,c);n.onupgradeneeded=()=>{let e=n.result;e.objectStoreNames.contains(`sqlite`)||e.createObjectStore(`sqlite`),e.objectStoreNames.contains(`crypto`)||e.createObjectStore(`crypto`)},n.onerror=()=>{b=null,t(n.error)},n.onsuccess=()=>{let t=n.result;t.onclose=()=>{b=null},e(t)}}),b)}var te=`mtj_erp_device_id`;function S(e){return x().then(t=>new Promise((n,r)=>{let i=t.transaction(`crypto`,`readwrite`).objectStore(`crypto`),a=i.get(te);a.onerror=()=>r(a.error),a.onsuccess=()=>{if(typeof a.result==`string`){n(a.result);return}let t=i.put(e,te);t.onerror=()=>r(t.error),t.onsuccess=()=>n(e)}}))}async function C(e){let t=await window.crypto.subtle.digest(`SHA-256`,e);return Array.from(new Uint8Array(t)).map(e=>e.toString(16).padStart(2,`0`)).join(``)}async function w(){let e=await x();return new Promise((t,n)=>{let r=e.transaction(`sqlite`,`readonly`).objectStore(`sqlite`).get(`db`);r.onsuccess=()=>t(r.result??null),r.onerror=()=>n(r.error)})}async function T(e){let t=await x();return new Promise((n,r)=>{let i=t.transaction(`sqlite`,`readwrite`).objectStore(`sqlite`).put(e,`db`);i.onsuccess=()=>n(),i.onerror=()=>r(i.error)})}var E=class extends Error{};async function ne(){let e=await w();if(!e)return null;let t=await V(await H(),e.encryptedBlob,e.iv),n=await C(t);if(n!==e.checksum)throw new E(`Local database checksum mismatch (expected ${e.checksum}, got ${n}) — the persisted database appears corrupted. Refusing to load it silently.`);return t}async function D(e,t){let n=await H(),r=await C(e),{blob:i,iv:a}=await Ce(n,e);await T({encryptedBlob:i,iv:a,checksum:r,schemaVersion:t,savedAt:new Date().toISOString()})}async function O(){return h||(h=await(0,i.default)({locateFile:()=>a}),h)}function re(){if(!g)throw Error(`SQLite DB not initialized`);g.run(`PRAGMA journal_mode = WAL;`),g.run(`PRAGMA synchronous = FULL;`),g.run(`CREATE TABLE IF NOT EXISTS meta (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
  );`),g.run(`CREATE TABLE IF NOT EXISTS branches (
    id TEXT PRIMARY KEY,
    name TEXT,
    code TEXT,
    address TEXT,
    phone TEXT,
    manager_name TEXT,
    gstin TEXT,
    active INTEGER DEFAULT 1,
    is_default INTEGER DEFAULT 0,
    notes TEXT,
    data TEXT,
    updated_at TEXT
  );`),g.run(`CREATE TABLE IF NOT EXISTS workshops (
    id TEXT PRIMARY KEY,
    name TEXT,
    type TEXT,
    branch_id TEXT,
    active INTEGER DEFAULT 1,
    description TEXT,
    data TEXT,
    FOREIGN KEY(branch_id) REFERENCES branches(id) ON DELETE SET NULL
  );`),g.run(`CREATE TABLE IF NOT EXISTS app_settings (
    id TEXT PRIMARY KEY,
    scope TEXT,
    data TEXT,
    updated_at TEXT
  );`),g.run(`CREATE TABLE IF NOT EXISTS branch_settings (
    branch_id TEXT PRIMARY KEY,
    address TEXT,
    phone TEXT,
    email TEXT,
    gstin TEXT,
    invoice_series TEXT,
    receipt_series TEXT,
    barcode_series TEXT,
    smtp_host TEXT,
    smtp_port TEXT,
    smtp_user TEXT,
    smtp_password TEXT,
    smtp_from_name TEXT,
    smtp_from_email TEXT,
    wa_phone_number TEXT,
    thermal_printer_ip TEXT,
    thermal_printer_port TEXT,
    default_karat INTEGER,
    gold_rate_source TEXT,
    invoice_template_id TEXT,
    receipt_template_id TEXT,
    logo_url TEXT,
    logo_storage_path TEXT,
    wa_config TEXT,
    wa_automations TEXT,
    updated_at TEXT,
    FOREIGN KEY(branch_id) REFERENCES branches(id) ON DELETE CASCADE
  );`),g.run(`CREATE TABLE IF NOT EXISTS people (
    id TEXT PRIMARY KEY,
    type TEXT,
    active INTEGER DEFAULT 1,
    full_name TEXT,
    phone TEXT,
    village_city TEXT,
    current_address TEXT,
    permanent_address TEXT,
    gstin TEXT,
    pan TEXT,
    aadhaar_masked TEXT,
    work_type TEXT,
    notes TEXT,
    branch_id TEXT,
    data TEXT,
    created_at INTEGER,
    updated_at INTEGER,
    FOREIGN KEY(branch_id) REFERENCES branches(id) ON DELETE SET NULL
  );`),g.run(`CREATE TABLE IF NOT EXISTS gold_ledger (
    id TEXT PRIMARY KEY,
    ts TEXT,
    movement TEXT,
    net_fine_mg INTEGER,
    bucket_deltas TEXT,
    reference TEXT,
    note TEXT,
    gross_mg INTEGER,
    purity INTEGER,
    fine_mg INTEGER,
    form TEXT,
    data TEXT
  );`),g.run(`CREATE TABLE IF NOT EXISTS orders (
    id TEXT PRIMARY KEY,
    order_no TEXT,
    type TEXT,
    status TEXT,
    customer_id TEXT,
    karigar_id TEXT,
    expected_delivery TEXT,
    priority TEXT,
    source TEXT,
    whatsapp_source_id TEXT,
    branch_id TEXT,
    data TEXT,
    FOREIGN KEY(customer_id) REFERENCES people(id) ON DELETE SET NULL,
    FOREIGN KEY(karigar_id) REFERENCES people(id) ON DELETE SET NULL,
    FOREIGN KEY(branch_id) REFERENCES branches(id) ON DELETE SET NULL
  );`),g.run(`CREATE TABLE IF NOT EXISTS job_cards (
    id TEXT PRIMARY KEY,
    job_no TEXT,
    order_id TEXT,
    karigar_id TEXT,
    status TEXT,
    template_key TEXT,
    branch_id TEXT,
    data TEXT,
    FOREIGN KEY(order_id) REFERENCES orders(id) ON DELETE SET NULL,
    FOREIGN KEY(karigar_id) REFERENCES people(id) ON DELETE SET NULL,
    FOREIGN KEY(branch_id) REFERENCES branches(id) ON DELETE SET NULL
  );`),g.run(`CREATE TABLE IF NOT EXISTS inventory (
    id TEXT PRIMARY KEY,
    item_code TEXT,
    barcode TEXT,
    huid TEXT,
    item_name TEXT,
    category TEXT,
    purity INTEGER,
    gross_mg INTEGER,
    net_mg INTEGER,
    status TEXT,
    location TEXT,
    branch_id TEXT,
    data TEXT,
    FOREIGN KEY(branch_id) REFERENCES branches(id) ON DELETE SET NULL
  );`),g.run(`CREATE TABLE IF NOT EXISTS stock_movements (
    id TEXT PRIMARY KEY,
    item_id TEXT,
    ts TEXT,
    kind TEXT,
    from_location TEXT,
    to_location TEXT,
    note TEXT,
    branch_id TEXT,
    data TEXT,
    FOREIGN KEY(item_id) REFERENCES inventory(id) ON DELETE CASCADE,
    FOREIGN KEY(branch_id) REFERENCES branches(id) ON DELETE SET NULL
  );`),g.run(`CREATE TABLE IF NOT EXISTS invoices (
    id TEXT PRIMARY KEY,
    invoice_no TEXT,
    customer_id TEXT,
    order_id TEXT,
    status TEXT,
    gst TEXT,
    subtotal_paise INTEGER,
    cgst_paise INTEGER,
    sgst_paise INTEGER,
    gst_paise INTEGER,
    adjustment_paise INTEGER,
    grand_total_paise INTEGER,
    paid_paise INTEGER,
    balance_paise INTEGER,
    branch_id TEXT,
    data TEXT,
    FOREIGN KEY(customer_id) REFERENCES people(id) ON DELETE SET NULL,
    FOREIGN KEY(order_id) REFERENCES orders(id) ON DELETE SET NULL,
    FOREIGN KEY(branch_id) REFERENCES branches(id) ON DELETE SET NULL
  );`),g.run(`CREATE TABLE IF NOT EXISTS payments (
    id TEXT PRIMARY KEY,
    invoice_id TEXT,
    ts TEXT,
    mode TEXT,
    amount_paise INTEGER,
    reference TEXT,
    notes TEXT,
    gold_gross_mg INTEGER,
    gold_purity INTEGER,
    gold_fine_mg INTEGER,
    gold_rate_per_gram_paise INTEGER,
    branch_id TEXT,
    data TEXT,
    FOREIGN KEY(invoice_id) REFERENCES invoices(id) ON DELETE CASCADE,
    FOREIGN KEY(branch_id) REFERENCES branches(id) ON DELETE SET NULL
  );`),g.run(`CREATE TABLE IF NOT EXISTS attendance (
    id TEXT PRIMARY KEY,
    worker_id TEXT,
    date TEXT,
    status TEXT,
    hours INTEGER,
    data TEXT,
    FOREIGN KEY(worker_id) REFERENCES people(id) ON DELETE SET NULL
  );`),g.run(`CREATE TABLE IF NOT EXISTS salary_rules (
    id TEXT PRIMARY KEY,
    name TEXT,
    data TEXT
  );`),g.run(`CREATE TABLE IF NOT EXISTS worker_transactions (
    id TEXT PRIMARY KEY,
    worker_id TEXT,
    kind TEXT,
    ts TEXT,
    amount_paise INTEGER,
    gold_mg INTEGER,
    branch_id TEXT,
    data TEXT,
    FOREIGN KEY(worker_id) REFERENCES people(id) ON DELETE SET NULL,
    FOREIGN KEY(branch_id) REFERENCES branches(id) ON DELETE SET NULL
  );`),g.run(`CREATE TABLE IF NOT EXISTS worker_settlements (
    id TEXT PRIMARY KEY,
    worker_id TEXT,
    period_from TEXT,
    period_to TEXT,
    branch_id TEXT,
    data TEXT,
    FOREIGN KEY(worker_id) REFERENCES people(id) ON DELETE SET NULL,
    FOREIGN KEY(branch_id) REFERENCES branches(id) ON DELETE SET NULL
  );`),g.run(`CREATE TABLE IF NOT EXISTS catalog_designs (
    id TEXT PRIMARY KEY,
    design_no TEXT,
    name TEXT,
    category TEXT,
    data TEXT
  );`),g.run(`CREATE TABLE IF NOT EXISTS rate_cut_records (
    id TEXT PRIMARY KEY,
    rate_cut_no TEXT,
    karigar_id TEXT,
    job_id TEXT,
    overloss_fine_mg INTEGER,
    gold_rate_per_gram_paise INTEGER,
    penalty_paise INTEGER,
    settlement_mode TEXT,
    data TEXT,
    FOREIGN KEY(karigar_id) REFERENCES people(id) ON DELETE SET NULL,
    FOREIGN KEY(job_id) REFERENCES job_cards(id) ON DELETE SET NULL
  );`),g.run(`CREATE TABLE IF NOT EXISTS repairs (
    id TEXT PRIMARY KEY,
    repair_no TEXT,
    customer_id TEXT,
    kind TEXT,
    status TEXT,
    received_gross_mg INTEGER,
    estimated_charge_paise INTEGER,
    advance_paise INTEGER,
    branch_id TEXT,
    data TEXT,
    FOREIGN KEY(customer_id) REFERENCES people(id) ON DELETE SET NULL,
    FOREIGN KEY(branch_id) REFERENCES branches(id) ON DELETE SET NULL
  );`),g.run(`CREATE TABLE IF NOT EXISTS daily_close (
    id TEXT PRIMARY KEY,
    data TEXT
  );`),g.run(`CREATE TABLE IF NOT EXISTS print_logs (
    id TEXT PRIMARY KEY,
    doc_type TEXT,
    doc_number TEXT,
    linked_id TEXT,
    linked_label TEXT,
    printed_by TEXT,
    first_printed_at TEXT,
    last_printed_at TEXT,
    reprint_count INTEGER,
    history TEXT,
    data TEXT
  );`),g.run(`CREATE TABLE IF NOT EXISTS whatsapp_inbox (
    id TEXT PRIMARY KEY,
    sender_name TEXT,
    sender_phone TEXT,
    raw_text TEXT,
    status TEXT,
    parsed TEXT,
    converted_order_id TEXT,
    linked_person_id TEXT,
    notes TEXT,
    created_at TEXT,
    updated_at TEXT
  );`),g.run(`CREATE TABLE IF NOT EXISTS communication_logs (
    id TEXT PRIMARY KEY,
    channel TEXT,
    direction TEXT,
    status TEXT,
    phone TEXT,
    body TEXT,
    linked_id TEXT,
    linked_table TEXT,
    data TEXT,
    created_at TEXT,
    updated_at TEXT
  );`),g.run(`CREATE TABLE IF NOT EXISTS approval_requests (
    id TEXT PRIMARY KEY,
    entity_type TEXT,
    entity_id TEXT,
    status TEXT,
    data TEXT,
    updated_at TEXT
  );`),g.run(`CREATE INDEX IF NOT EXISTS idx_approval_requests_status ON approval_requests(entity_type, status);`),g.run(`CREATE TABLE IF NOT EXISTS stone_details (
    id TEXT PRIMARY KEY,
    stock_item_id TEXT,
    data TEXT,
    updated_at TEXT
  );`),g.run(`CREATE INDEX IF NOT EXISTS idx_stone_details_item ON stone_details(stock_item_id);`),g.run(`CREATE TABLE IF NOT EXISTS lot_batches (
    id TEXT PRIMARY KEY,
    data TEXT,
    updated_at TEXT
  );`),g.run(`CREATE TABLE IF NOT EXISTS saved_filters (
    id TEXT PRIMARY KEY,
    data TEXT,
    updated_at TEXT
  );`),g.run(`CREATE TABLE IF NOT EXISTS credit_notes (id TEXT PRIMARY KEY, data TEXT, updated_at TEXT);`),g.run(`CREATE TABLE IF NOT EXISTS debit_notes (id TEXT PRIMARY KEY, data TEXT, updated_at TEXT);`),g.run(`CREATE TABLE IF NOT EXISTS estimates (id TEXT PRIMARY KEY, data TEXT, updated_at TEXT);`),g.run(`CREATE TABLE IF NOT EXISTS delivery_challans (id TEXT PRIMARY KEY, data TEXT, updated_at TEXT);`),g.run(`CREATE TABLE IF NOT EXISTS order_issues (id TEXT PRIMARY KEY, data TEXT, updated_at TEXT);`),g.run(`CREATE TABLE IF NOT EXISTS worker_returns (id TEXT PRIMARY KEY, data TEXT, updated_at TEXT);`),g.run(`CREATE TABLE IF NOT EXISTS material_vault_movements (id TEXT PRIMARY KEY, data TEXT, updated_at TEXT);`),g.run(`CREATE TABLE IF NOT EXISTS outside_work_transactions (id TEXT PRIMARY KEY, data TEXT, updated_at TEXT);`),g.run(`CREATE TABLE IF NOT EXISTS polishing_transactions (id TEXT PRIMARY KEY, data TEXT, updated_at TEXT);`),g.run(`CREATE TABLE IF NOT EXISTS manufacturing_barcodes (id TEXT PRIMARY KEY, data TEXT, updated_at TEXT);`),g.run(`CREATE TABLE IF NOT EXISTS outside_work_labour_charges (id TEXT PRIMARY KEY, data TEXT, updated_at TEXT);`),g.run(`CREATE TABLE IF NOT EXISTS outside_work_payments (id TEXT PRIMARY KEY, data TEXT, updated_at TEXT);`),g.run(`CREATE TABLE IF NOT EXISTS customer_settlements (id TEXT PRIMARY KEY, data TEXT, updated_at TEXT);`),g.run(`CREATE TABLE IF NOT EXISTS local_users (
    id TEXT PRIMARY KEY,
    name TEXT,
    email TEXT UNIQUE,
    phone TEXT,
    role TEXT,
    branch_id TEXT,
    password_hash TEXT,
    password_salt TEXT,
    last_password_change TEXT,
    failed_login_count INTEGER DEFAULT 0,
    active INTEGER DEFAULT 1,
    is_super_owner INTEGER DEFAULT 0,
    recovery_question_1 TEXT,
    recovery_answer_hash_1 TEXT,
    recovery_question_2 TEXT,
    recovery_answer_hash_2 TEXT,
    recovery_key_hash TEXT,
    created_at TEXT,
    updated_at TEXT
  );`),g.run(`CREATE INDEX IF NOT EXISTS idx_local_users_email ON local_users(email);`),g.run(`CREATE TABLE IF NOT EXISTS user_sessions (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    role TEXT,
    branch_id TEXT,
    login_at TEXT,
    ended_at TEXT,
    device_id TEXT,
    deployment_mode TEXT,
    FOREIGN KEY(user_id) REFERENCES local_users(id) ON DELETE CASCADE
  );`),g.run(`CREATE INDEX IF NOT EXISTS idx_user_sessions_user_id ON user_sessions(user_id);`),g.run(`CREATE TABLE IF NOT EXISTS module_states (
    id TEXT PRIMARY KEY,
    branch_id TEXT,
    module_key TEXT,
    enabled INTEGER,
    updated_at TEXT,
    data TEXT,
    FOREIGN KEY(branch_id) REFERENCES branches(id) ON DELETE SET NULL
  );`),g.run(`CREATE TABLE IF NOT EXISTS dropdown_masters (
    id TEXT PRIMARY KEY,
    master_key TEXT,
    value TEXT,
    active INTEGER,
    sort_order INTEGER,
    data TEXT
  );`),g.run(`CREATE TABLE IF NOT EXISTS manufacturing_bills (
    id TEXT PRIMARY KEY,
    data TEXT
  );`),g.run(`CREATE TABLE IF NOT EXISTS melt_jobs (
    id TEXT PRIMARY KEY,
    data TEXT
  );`),g.run(`CREATE TABLE IF NOT EXISTS gold_settlements (
    id TEXT PRIMARY KEY,
    data TEXT
  );`),g.run(`CREATE TABLE IF NOT EXISTS crm_leads_opportunities (
    id TEXT PRIMARY KEY,
    data TEXT
  );`),g.run(`CREATE TABLE IF NOT EXISTS crm_tasks_meetings (
    id TEXT PRIMARY KEY,
    data TEXT
  );`),g.run(`CREATE TABLE IF NOT EXISTS crm_interactions (
    id TEXT PRIMARY KEY,
    data TEXT
  );`),g.run(`CREATE TABLE IF NOT EXISTS attachments (
    id TEXT PRIMARY KEY,
    file_name TEXT,
    kind TEXT,
    linked_id TEXT,
    linked_table TEXT,
    storage_path TEXT,
    bucket TEXT,
    size_bytes INTEGER,
    mime_type TEXT,
    data TEXT
  );`),g.run(`CREATE TABLE IF NOT EXISTS attachment_files (
    attachment_id TEXT PRIMARY KEY,
    encrypted_blob BLOB,
    iv BLOB,
    mime_type TEXT,
    size_bytes INTEGER,
    FOREIGN KEY(attachment_id) REFERENCES attachments(id) ON DELETE CASCADE
  );`),g.run(`CREATE TABLE IF NOT EXISTS file_blobs (
    checksum TEXT PRIMARY KEY,
    encrypted_blob BLOB NOT NULL,
    iv BLOB NOT NULL,
    size_bytes INTEGER NOT NULL,
    mime_type TEXT,
    ref_count INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL,
    last_verified_at TEXT,
    corrupted INTEGER NOT NULL DEFAULT 0
  );`),g.run(`CREATE TABLE IF NOT EXISTS auto_backups (
    id TEXT PRIMARY KEY,
    created_at TEXT NOT NULL,
    schema_version INTEGER NOT NULL,
    checksum TEXT NOT NULL,
    size_bytes INTEGER NOT NULL,
    valid INTEGER NOT NULL DEFAULT 0,
    encrypted_blob BLOB NOT NULL,
    iv BLOB NOT NULL
  );`),g.run(`CREATE INDEX IF NOT EXISTS idx_auto_backups_created ON auto_backups(created_at);`),g.run(`CREATE TABLE IF NOT EXISTS file_versions (
    id TEXT PRIMARY KEY,
    attachment_id TEXT NOT NULL,
    entity_type TEXT,
    entity_id TEXT,
    file_name TEXT,
    version INTEGER NOT NULL,
    checksum TEXT NOT NULL,
    is_current INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL,
    created_by TEXT,
    cloud_backed_up INTEGER NOT NULL DEFAULT 0,
    FOREIGN KEY(checksum) REFERENCES file_blobs(checksum)
  );`),g.run(`CREATE INDEX IF NOT EXISTS idx_file_versions_attachment ON file_versions(attachment_id);`),g.run(`CREATE INDEX IF NOT EXISTS idx_file_versions_current ON file_versions(attachment_id, is_current);`),g.run(`CREATE INDEX IF NOT EXISTS idx_file_versions_entity ON file_versions(entity_type, entity_id);`),g.run(`CREATE TABLE IF NOT EXISTS audit_log (
    seq INTEGER PRIMARY KEY AUTOINCREMENT,
    id TEXT NOT NULL UNIQUE,
    ts TEXT NOT NULL,
    actor_id TEXT,
    actor_email TEXT,
    action TEXT NOT NULL,
    entity_type TEXT NOT NULL,
    entity_id TEXT,
    before_json TEXT,
    after_json TEXT,
    device_id TEXT,
    prev_hash TEXT NOT NULL,
    hash TEXT NOT NULL,
    signature TEXT NOT NULL
  );`),g.run(`CREATE INDEX IF NOT EXISTS idx_audit_log_entity ON audit_log(entity_type, entity_id);`),g.run(`CREATE INDEX IF NOT EXISTS idx_audit_log_actor ON audit_log(actor_id);`),g.run(`CREATE INDEX IF NOT EXISTS idx_audit_log_ts ON audit_log(ts);`),g.run(`CREATE TABLE IF NOT EXISTS device_registry (
    device_id TEXT PRIMARY KEY,
    label TEXT NOT NULL,
    platform TEXT,
    first_seen_at TEXT NOT NULL,
    last_seen_at TEXT NOT NULL,
    trusted INTEGER NOT NULL DEFAULT 1
  );`),g.run(`CREATE TABLE IF NOT EXISTS escalation_state (
    entity_type TEXT NOT NULL,
    entity_id TEXT NOT NULL,
    first_flagged_at TEXT NOT NULL,
    last_tier_index INTEGER NOT NULL DEFAULT -1,
    last_sent_at TEXT,
    PRIMARY KEY (entity_type, entity_id)
  );`),g.run(`CREATE TABLE IF NOT EXISTS print_jobs (
    id TEXT PRIMARY KEY,
    doc_type TEXT NOT NULL,
    title TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending',
    attempts INTEGER NOT NULL DEFAULT 0,
    last_error TEXT,
    pdf_file_name TEXT,
    created_at TEXT NOT NULL,
    completed_at TEXT
  );`),g.run(`CREATE INDEX IF NOT EXISTS idx_print_jobs_status ON print_jobs(status);`),g.run(`CREATE TABLE IF NOT EXISTS print_templates (
    id TEXT PRIMARY KEY,
    data TEXT,
    updated_at TEXT
  );`),g.run(`CREATE TABLE IF NOT EXISTS gold_reconciliation_reports (
    id TEXT PRIMARY KEY,
    generated_at TEXT NOT NULL,
    branch_id TEXT,
    total_checked INTEGER NOT NULL,
    exception_count INTEGER NOT NULL,
    report_json TEXT NOT NULL
  );`),g.run(`CREATE INDEX IF NOT EXISTS idx_gold_recon_generated ON gold_reconciliation_reports(generated_at);`),g.run(`CREATE TABLE IF NOT EXISTS scheduled_jobs (
    job_key TEXT PRIMARY KEY,
    last_run_at TEXT,
    last_status TEXT,
    last_error TEXT
  );`),g.run(`CREATE TABLE IF NOT EXISTS comm_queue (
    id TEXT PRIMARY KEY,
    request TEXT NOT NULL,
    log_event_id TEXT,
    status TEXT NOT NULL DEFAULT 'pending',
    attempts INTEGER NOT NULL DEFAULT 0,
    last_error TEXT,
    last_attempt_at TEXT,
    next_attempt_at TEXT,
    created_at TEXT NOT NULL,
    sent_at TEXT
  );`),g.run(`CREATE INDEX IF NOT EXISTS idx_comm_queue_status ON comm_queue(status);`),g.run(`CREATE TABLE IF NOT EXISTS outbox (
    id TEXT PRIMARY KEY,
    table_name TEXT NOT NULL,
    row_id TEXT NOT NULL,
    operation TEXT NOT NULL,
    payload TEXT,
    status TEXT DEFAULT 'pending',
    attempts INTEGER DEFAULT 0,
    last_error TEXT,
    last_attempt_at TEXT,
    created_at TEXT NOT NULL,
    base_updated_at TEXT,
    next_attempt_at TEXT
  );`),g.run(`CREATE TABLE IF NOT EXISTS sync_conflicts (
    id TEXT PRIMARY KEY,
    table_name TEXT NOT NULL,
    row_id TEXT NOT NULL,
    local_payload TEXT,
    remote_payload TEXT,
    detected_at TEXT NOT NULL,
    resolved INTEGER DEFAULT 0,
    resolution TEXT
  );`),g.run(`CREATE INDEX IF NOT EXISTS idx_sync_conflicts_resolved ON sync_conflicts(resolved);`),g.run(`CREATE TABLE IF NOT EXISTS sync_meta (
    table_name TEXT PRIMARY KEY,
    last_pulled_at TEXT,
    last_pushed_at TEXT
  );`),g.run(`CREATE TABLE IF NOT EXISTS row_sync_state (
    table_name TEXT NOT NULL,
    row_id TEXT NOT NULL,
    last_synced_updated_at TEXT,
    PRIMARY KEY (table_name, row_id)
  );`),g.run(`CREATE TABLE IF NOT EXISTS financial_lock_periods (
    id TEXT PRIMARY KEY,
    branch_id TEXT,
    period TEXT,
    data TEXT
  );`),g.run(`CREATE INDEX IF NOT EXISTS idx_financial_lock_periods_branch_period ON financial_lock_periods(branch_id, period);`),g.run(`CREATE TABLE IF NOT EXISTS physical_stock_counts (
    id TEXT PRIMARY KEY,
    branch_id TEXT,
    status TEXT,
    data TEXT
  );`),g.run(`CREATE INDEX IF NOT EXISTS idx_physical_stock_counts_branch_id ON physical_stock_counts(branch_id);`),g.run(`CREATE TABLE IF NOT EXISTS stock_lots (
    id TEXT PRIMARY KEY,
    branch_id TEXT,
    lot_number TEXT,
    status TEXT,
    data TEXT
  );`),g.run(`CREATE INDEX IF NOT EXISTS idx_stock_lots_branch_id ON stock_lots(branch_id);`),g.run(`CREATE INDEX IF NOT EXISTS idx_stock_lots_lot_number ON stock_lots(lot_number);`),g.run(`CREATE TABLE IF NOT EXISTS stock_stones (
    id TEXT PRIMARY KEY,
    branch_id TEXT,
    item_id TEXT,
    stone_type TEXT,
    certificate_number TEXT,
    data TEXT
  );`),g.run(`CREATE INDEX IF NOT EXISTS idx_stock_stones_branch_id ON stock_stones(branch_id);`),g.run(`CREATE INDEX IF NOT EXISTS idx_stock_stones_item_id ON stock_stones(item_id);`),g.run(`CREATE TABLE IF NOT EXISTS hallmark_batches (
    id TEXT PRIMARY KEY,
    branch_id TEXT,
    batch_number TEXT,
    status TEXT,
    data TEXT
  );`),g.run(`CREATE INDEX IF NOT EXISTS idx_hallmark_batches_branch_id ON hallmark_batches(branch_id);`),g.run(`CREATE INDEX IF NOT EXISTS idx_hallmark_batches_status ON hallmark_batches(status);`),g.run(`CREATE TABLE IF NOT EXISTS deleted_rows (
    table_name TEXT NOT NULL,
    row_id TEXT NOT NULL,
    deleted_at TEXT NOT NULL,
    PRIMARY KEY (table_name, row_id)
  );`),g.run(`CREATE INDEX IF NOT EXISTS idx_deleted_rows_table ON deleted_rows(table_name);`),g.run(`CREATE INDEX IF NOT EXISTS idx_outbox_status ON outbox(status);`),g.run(`CREATE INDEX IF NOT EXISTS idx_outbox_table_row ON outbox(table_name, row_id);`),g.run(`CREATE INDEX IF NOT EXISTS idx_branches_is_default ON branches(is_default);`),g.run(`CREATE INDEX IF NOT EXISTS idx_workshops_branch_id ON workshops(branch_id);`),g.run(`CREATE INDEX IF NOT EXISTS idx_inventory_branch_id ON inventory(branch_id);`),g.run(`CREATE INDEX IF NOT EXISTS idx_inventory_barcode ON inventory(barcode);`),g.run(`CREATE INDEX IF NOT EXISTS idx_inventory_status ON inventory(status);`),g.run(`CREATE INDEX IF NOT EXISTS idx_orders_branch_id ON orders(branch_id);`),g.run(`CREATE INDEX IF NOT EXISTS idx_orders_customer_id ON orders(customer_id);`),g.run(`CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);`),g.run(`CREATE INDEX IF NOT EXISTS idx_invoices_customer_id ON invoices(customer_id);`),g.run(`CREATE INDEX IF NOT EXISTS idx_invoices_branch_id ON invoices(branch_id);`),g.run(`CREATE INDEX IF NOT EXISTS idx_invoices_status ON invoices(status);`),g.run(`CREATE INDEX IF NOT EXISTS idx_payments_invoice_id ON payments(invoice_id);`),g.run(`CREATE INDEX IF NOT EXISTS idx_people_type ON people(type);`),g.run(`CREATE INDEX IF NOT EXISTS idx_people_phone ON people(phone);`),g.run(`CREATE INDEX IF NOT EXISTS idx_people_full_name ON people(full_name);`),g.run(`CREATE INDEX IF NOT EXISTS idx_people_branch_id ON people(branch_id);`),g.run(`CREATE INDEX IF NOT EXISTS idx_job_cards_order_id ON job_cards(order_id);`),g.run(`CREATE INDEX IF NOT EXISTS idx_job_cards_karigar_id ON job_cards(karigar_id);`),g.run(`CREATE INDEX IF NOT EXISTS idx_job_cards_status ON job_cards(status);`),g.run(`CREATE INDEX IF NOT EXISTS idx_stock_movements_item_id ON stock_movements(item_id);`),g.run(`CREATE INDEX IF NOT EXISTS idx_worker_transactions_worker_id ON worker_transactions(worker_id);`),g.run(`CREATE INDEX IF NOT EXISTS idx_worker_settlements_worker_id ON worker_settlements(worker_id);`),g.run(`CREATE INDEX IF NOT EXISTS idx_attendance_worker_id ON attendance(worker_id);`),g.run(`CREATE INDEX IF NOT EXISTS idx_repairs_customer_id ON repairs(customer_id);`),g.run(`CREATE INDEX IF NOT EXISTS idx_rate_cut_records_karigar_id ON rate_cut_records(karigar_id);`),g.run(`CREATE INDEX IF NOT EXISTS idx_attachments_linked ON attachments(linked_table, linked_id);`)}function k(e,t,n,r){let i=e.prepare(`PRAGMA table_info(${t});`),a=[];for(;i.step();)a.push(String(i.getAsObject().name));i.free(),!a.includes(n)&&e.run(`ALTER TABLE ${t} ADD COLUMN ${n} ${r};`)}var ie=[{version:2,up:e=>{k(e,`local_users`,`branch_id`,`TEXT`),k(e,`local_users`,`last_password_change`,`TEXT`),k(e,`local_users`,`failed_login_count`,`INTEGER DEFAULT 0`)}},{version:3,up:()=>{}},{version:4,up:e=>{k(e,`local_users`,`recovery_question_1`,`TEXT`),k(e,`local_users`,`recovery_answer_hash_1`,`TEXT`),k(e,`local_users`,`recovery_question_2`,`TEXT`),k(e,`local_users`,`recovery_answer_hash_2`,`TEXT`),k(e,`local_users`,`recovery_key_hash`,`TEXT`)}}];function A(e){let t=e.prepare(`SELECT value FROM meta WHERE key = 'schema_version';`),n=t.step()?Number(t.getAsObject().value):0;return t.free(),n}function ae(e,t){e.run(`INSERT OR REPLACE INTO meta (key, value) VALUES ('schema_version', ?);`,[String(t)])}function oe(e){let t=N().prepare(`SELECT value FROM meta WHERE key = ?;`);t.bind([e]);let n=t.step()?String(t.getAsObject().value):null;return t.free(),n}function se(e,t){N().run(`INSERT OR REPLACE INTO meta (key, value) VALUES (?, ?);`,[e,t])}function ce(e){let t=A(e),n=ie.filter(e=>e.version>t).sort((e,t)=>e.version-t.version);for(let t of n){e.run(`BEGIN IMMEDIATE;`);try{t.up(e),ae(e,t.version),e.run(`COMMIT;`)}catch(n){throw e.run(`ROLLBACK;`),Error(`Migration to schema version ${t.version} failed and was rolled back: ${n instanceof Error?n.message:String(n)}`)}}}function le(){let e=N().prepare(`PRAGMA integrity_check;`),t=[];for(;e.step();){let n=e.getAsObject(),r=String(n.integrity_check??``);r&&r!==`ok`&&t.push(r)}return e.free(),{ok:t.length===0,issues:t}}async function ue(){let e=await O(),t;try{t=await ne()}catch(e){throw e instanceof E,e}g=t?new e.Database(t):new e.Database;let n=t?A(g):0,r=!t||n<c;r&&re(),g.run(`PRAGMA foreign_keys = ON;`),t?ce(g):ae(g,c);let i=le();if(!i.ok)throw new E(`SQLite PRAGMA integrity_check failed: ${i.issues.join(`; `)}`);r&&await D(new Uint8Array(g.export()),A(g))}var de=2e4;async function j(){if(_)return _;let e=(async()=>{let e,t=new Promise((t,n)=>{e=setTimeout(()=>n(Error(`Local database initialization timed out`)),de)});try{await Promise.race([ue(),t])}finally{e&&clearTimeout(e)}})();_=e;try{await e}catch(e){throw _=null,e}}async function M(){g=null,_=null,h=null,b&&=((await b.catch(()=>null))?.close(),null),await new Promise((e,t)=>{let n=window.indexedDB.deleteDatabase(s);n.onsuccess=()=>e(),n.onerror=()=>t(n.error),n.onblocked=()=>e()})}function N(){if(!g)throw Error(`SQLite DB is not initialized`);return g.run(`PRAGMA foreign_keys = ON;`),g}var fe=Promise.resolve(),P=!1;function F(e){if(P)return Promise.resolve().then(e);let t=fe.then(async()=>{await j();let t=N();t.run(`BEGIN IMMEDIATE;`),P=!0;try{let n=await e();return t.run(`COMMIT;`),await D(new Uint8Array(t.export()),A(t)),n}catch(e){throw t.run(`ROLLBACK;`),e}finally{P=!1}});return fe=t.catch(()=>{}),t}function pe(e){let t=N().prepare(`SELECT * FROM ${e}`),n=[];for(;t.step();)n.push(y(t.getAsObject()));return t.free(),n}function I(e,t){let n=N().prepare(`SELECT * FROM ${e} WHERE id = ?`);n.bind([t]);let r=n.step()?y(n.getAsObject()):null;return n.free(),r}function me(e,t){N().run(`DELETE FROM ${e} WHERE id = ?;`,[t])}function L(e,t){let n=N(),r=Object.keys(t),i=r.map(e=>e).join(`, `),a=r.map(()=>`?`).join(`, `),o=r.map(e=>v(t[e]));n.run(`INSERT INTO ${e} (${i}) VALUES (${a}) ON CONFLICT(id) DO UPDATE SET ${r.filter(e=>e!==`id`).map(e=>`${e} = excluded.${e}`).join(`, `)};`,o)}function he(e,t){for(let n of t)L(e,n)}function ge(e,t){N().run(`INSERT OR REPLACE INTO deleted_rows (table_name, row_id, deleted_at) VALUES (?, ?, ?);`,[e,t,new Date().toISOString()])}function _e(e,t){let n=N().prepare(`SELECT 1 FROM deleted_rows WHERE table_name = ? AND row_id = ?;`);n.bind([e,t]);let r=n.step();return n.free(),r}function ve(e,t){N().run(`DELETE FROM deleted_rows WHERE table_name = ? AND row_id = ?;`,[e,t])}function ye(e,t){let n=N();n.run(`DELETE FROM ${e} WHERE id = ?;`,[t]),n.run(`DELETE FROM deleted_rows WHERE table_name = ? AND row_id = ?;`,[e,t])}function R(e){let t=N().prepare(`SELECT t.* FROM ${e} t WHERE NOT EXISTS (SELECT 1 FROM deleted_rows d WHERE d.table_name = ? AND d.row_id = t.id)`);t.bind([e]);let n=[];for(;t.step();)n.push(y(t.getAsObject()));return t.free(),n}function be(e,t=``,n=[]){let r=N(),i=t?`SELECT * FROM ${e} WHERE ${t}`:`SELECT * FROM ${e}`,a=r.prepare(i);a.bind(n);let o=[];for(;a.step();)o.push(y(a.getAsObject()));return a.free(),o}function z(){return be(`outbox`,`status = ?`,[`pending`])}function B(e){if(!e)return null;let t=e.updatedAt??e.updated_at;return t==null?null:typeof t==`number`?new Date(t).toISOString():String(t)}function xe(e,t,n,r,i,a){let o=new Date().toISOString();L(`outbox`,{id:e,table_name:t,row_id:n,operation:r,payload:i==null?null:JSON.stringify(i),status:`pending`,attempts:0,last_error:null,last_attempt_at:null,created_at:o,base_updated_at:a??null,next_attempt_at:o})}function Se(e,t,n){let r=N(),i=new Date().toISOString();r.run(`UPDATE outbox SET status = ?, attempts = attempts + 1, last_error = ?, last_attempt_at = ? WHERE id = ?;`,[t,n??null,i,e])}async function Ce(e,t){let n=window.crypto.getRandomValues(new Uint8Array(12)),r=await window.crypto.subtle.encrypt({name:`AES-GCM`,iv:n},e,t);return{blob:new Uint8Array(r),iv:n}}async function V(e,t,n){let r=await window.crypto.subtle.decrypt({name:`AES-GCM`,iv:n},e,t);return new Uint8Array(r)}async function H(){let e=f();if(e){let t=await e.get(u);if(t)return window.crypto.subtle.importKey(`raw`,ee(t),`AES-GCM`,!0,[`encrypt`,`decrypt`])}let t=await x(),n=await new Promise((e,n)=>{let r=t.transaction(`crypto`,`readwrite`).objectStore(`crypto`).get(l);r.onsuccess=()=>e(r.result??null),r.onerror=()=>n(r.error)});if(n instanceof ArrayBuffer)return e&&(await e.set(u,p(new Uint8Array(n))),await m(t,l)),window.crypto.subtle.importKey(`raw`,n,`AES-GCM`,!0,[`encrypt`,`decrypt`]);let r=await window.crypto.subtle.generateKey({name:`AES-GCM`,length:256},!0,[`encrypt`,`decrypt`]),i=await window.crypto.subtle.exportKey(`raw`,r);return e?(await e.set(u,p(new Uint8Array(i))),r):(await new Promise((e,n)=>{let r=t.transaction(`crypto`,`readwrite`).objectStore(`crypto`).put(i,l);r.onsuccess=()=>e(),r.onerror=()=>n(r.error)}),r)}var U=`mtj_erp_signing_key`;async function we(){let e=f();if(e){let t=await e.get(d);if(t)return window.crypto.subtle.importKey(`raw`,ee(t),{name:`HMAC`,hash:`SHA-256`},!0,[`sign`,`verify`])}let t=await x(),n=await new Promise((e,n)=>{let r=t.transaction(`crypto`,`readwrite`).objectStore(`crypto`).get(U);r.onsuccess=()=>e(r.result??null),r.onerror=()=>n(r.error)});if(n instanceof ArrayBuffer)return e&&(await e.set(d,p(new Uint8Array(n))),await m(t,U)),window.crypto.subtle.importKey(`raw`,n,{name:`HMAC`,hash:`SHA-256`},!0,[`sign`,`verify`]);let r=await window.crypto.subtle.generateKey({name:`HMAC`,hash:`SHA-256`},!0,[`sign`,`verify`]),i=await window.crypto.subtle.exportKey(`raw`,r);return e?(await e.set(d,p(new Uint8Array(i))),r):(await new Promise((e,n)=>{let r=t.transaction(`crypto`,`readwrite`).objectStore(`crypto`).put(i,U);r.onsuccess=()=>e(),r.onerror=()=>n(r.error)}),r)}async function Te(){await j();let e=await H(),t=await w(),n=t?await V(e,t.encryptedBlob,t.iv):null,r=t?.schemaVersion,i=be(`file_blobs`,``,[]),a=[];for(let t of i){let n=await V(e,t.encrypted_blob,t.iv);a.push({checksum:t.checksum,plaintext:n})}let o=await x(),s=await window.crypto.subtle.generateKey({name:`AES-GCM`,length:256},!0,[`encrypt`,`decrypt`]),c=await window.crypto.subtle.exportKey(`raw`,s),d=f();d&&await d.set(u,p(new Uint8Array(c))),await new Promise((e,t)=>{let n=o.transaction(`crypto`,`readwrite`).objectStore(`crypto`),r=d?n.delete(l):n.put(c,l);r.onsuccess=()=>e(),r.onerror=()=>t(r.error)}),n&&r!==void 0&&await D(n,r);for(let{checksum:e,plaintext:t}of a){let{blob:n,iv:r}=await Ce(s,t);await F(()=>{N().run(`UPDATE file_blobs SET encrypted_blob = ?, iv = ? WHERE checksum = ?;`,[n,r,e])})}return{rotated:!0,filesReencrypted:a.length}}async function Ee(e,t,n){let{blob:r,iv:i}=await Ce(await H(),t);L(`attachment_files`,{attachment_id:e,encrypted_blob:r,iv:i,mime_type:n,size_bytes:t.byteLength})}async function W(e){let t=I(`attachment_files`,e);if(!t)return null;let n=t.encrypted_blob,r=t.iv;return!n||!r?null:V(await H(),n,r)}async function De(){await j();let e=N(),t=le();if(!t.ok)throw new E(`Refusing to create a backup of a database that failed integrity_check: ${t.issues.join(`; `)}`);let n=new Uint8Array(e.export()),r=await C(n),{blob:i,iv:a}=await Ce(await H(),n);return{schemaVersion:A(e),checksum:r,createdAt:new Date().toISOString(),encryptedBlob:i,iv:a}}async function G(e){let t=await O(),n=await V(await H(),e.encryptedBlob,e.iv),r=await C(n);if(r!==e.checksum)throw new E(`Backup snapshot checksum mismatch (expected ${e.checksum}, got ${r}) — refusing to restore a corrupted backup.`);let i=new t.Database(n),a=i.prepare(`PRAGMA integrity_check;`),o=[];for(;a.step();){let e=String(a.getAsObject().integrity_check??``);e&&e!==`ok`&&o.push(e)}if(a.free(),o.length>0)throw i.close(),new E(`Backup snapshot failed PRAGMA integrity_check after decryption: ${o.join(`; `)}`);g?.close(),g=i,g.run(`PRAGMA foreign_keys = ON;`),g.run(`PRAGMA journal_mode = WAL;`),await D(n,e.schemaVersion)}async function Oe(e){let t=[],n=!1,r=!1,i=0;try{let a=await V(await H(),e.encryptedBlob,e.iv);i=a.byteLength;let o=await C(a);n=o===e.checksum,n||t.push(`Checksum mismatch (expected ${e.checksum}, got ${o}).`);let s=new(await(O())).Database(a);try{let e=s.prepare(`PRAGMA integrity_check;`),n=[];for(;e.step();){let t=String(e.getAsObject().integrity_check??``);t&&t!==`ok`&&n.push(t)}e.free(),r=n.length===0,t.push(...n)}finally{s.close()}}catch(e){t.push(e instanceof Error?e.message:String(e))}return{ok:n&&r,checksumVerified:n,integrityCheckPassed:r,sizeBytes:i,issues:t}}function ke(){return typeof crypto<`u`&&`randomUUID`in crypto?`bkp_${crypto.randomUUID()}`:`bkp_${Date.now()}_${Math.random().toString(36).slice(2,10)}`}async function K(e){await j();let t=N(),n=await De(),r=await Oe(n),i=ke();return t.run(`INSERT INTO auto_backups (id, created_at, schema_version, checksum, size_bytes, valid, encrypted_blob, iv)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?);`,[i,n.createdAt,n.schemaVersion,n.checksum,r.sizeBytes,+!!r.ok,n.encryptedBlob,n.iv]),await D(new Uint8Array(t.export()),n.schemaVersion),await q(Math.max(1,e)),{id:i,createdAt:n.createdAt,schemaVersion:n.schemaVersion,checksum:n.checksum,sizeBytes:r.sizeBytes,valid:r.ok}}function Ae(){let e=N().prepare(`SELECT id, created_at, schema_version, checksum, size_bytes, valid FROM auto_backups ORDER BY created_at DESC;`),t=[];for(;e.step();){let n=e.getAsObject();t.push({id:String(n.id),createdAt:String(n.created_at),schemaVersion:Number(n.schema_version),checksum:String(n.checksum),sizeBytes:Number(n.size_bytes),valid:Number(n.valid)===1})}return e.free(),t}function je(e){let t=N().prepare(`SELECT schema_version, checksum, created_at, encrypted_blob, iv FROM auto_backups WHERE id = ?;`);if(t.bind([e]),!t.step())return t.free(),null;let n=t.getAsObject();return t.free(),{schemaVersion:Number(n.schema_version),checksum:String(n.checksum),createdAt:String(n.created_at),encryptedBlob:n.encrypted_blob,iv:n.iv}}async function q(e){let t=N(),n=Ae(),r=n.find(e=>e.valid)?.id,i=n.slice(e).filter(e=>e.id!==r).map(e=>e.id);for(let e of i)t.run(`DELETE FROM auto_backups WHERE id = ?;`,[e]);i.length>0&&await D(new Uint8Array(t.export()),A(t))}var Me={open:j,getDatabase:N,runTransaction:F,getSchemaVersion:()=>A(N()),getTargetSchemaVersion:()=>c,checkIntegrity:le,createBackup:De,restoreBackup:G};export{I as C,ve as D,ge as E,L as O,R as S,C as T,ye as _,V as a,Te as b,B as c,H as d,we as f,S as g,o as h,De as i,Oe as k,N as l,j as m,M as n,Ce as o,z as p,K as r,xe as s,he as t,oe as u,be as v,se as w,F as x,G as y};