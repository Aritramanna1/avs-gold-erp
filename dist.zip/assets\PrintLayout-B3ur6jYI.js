import{i as e}from"./rolldown-runtime-aKtaBQYM.js";import{m as t}from"./vendor-charts-Bv77YuA6.js";import{i as n}from"./vendor-react-BbySHAOQ.js";import{t as r}from"./react-yId0ar3t.js";import{l as i}from"./settings-store-Dz_o_MeA.js";import{t as a}from"./middleware-Pd0e8Igk.js";import{t as o}from"./Logo-C1C-Rbsj.js";import{t as s}from"./print-qr-By2p7ihT.js";import{t as c}from"./AvsPrintFooter-B2c6JnhL.js";var l=e(t(),1),u={sizeOverride:null,orientation:null,margins:null,scalePct:100,fitToPage:!0},d=r()(a(e=>({...u,setSizeOverride:t=>e({sizeOverride:t}),setOrientation:t=>e({orientation:t}),setMargins:t=>e({margins:t}),setScalePct:t=>e({scalePct:Math.min(200,Math.max(25,t||100))}),setFitToPage:t=>e({fitToPage:t}),reset:()=>e({...u})}),{name:`mtj-print-setup-v1`})),f=n(),p={a4:`A4 (210 × 297mm)`,a5:`A5 (148 × 210mm)`,a5l:`Half A4 / A5 Landscape (210 × 148mm)`,a6:`A6 (105 × 148mm)`,thermal:`Thermal 80mm`,thermal58:`Thermal 58mm`,tag:`Tag / Label (50 × 30mm)`},m={a4:`A4 portrait`,a5:`A5 portrait`,a5l:`A5 landscape`,a6:`A6 portrait`,thermal:`80mm auto`,thermal58:`58mm auto`,tag:`50mm 30mm`},h=[`a4`,`a5`,`a5l`,`a6`];function g(e){return e===`a5l`?`landscape`:`portrait`}function _(e,t){let n=m[e];return!t||!h.includes(e)?n:`${n.split(` `)[0]} ${t}`}var v=96/25.4,y={a4:{width:210,height:297},a5:{width:148,height:210},a5l:{width:210,height:148},a6:{width:105,height:148}};function b(e,t){let n=y[e];if(!n)return;let r=t===`landscape`,i=Math.max(n.width,n.height),a=Math.min(n.width,n.height);return r?{width:i,height:a}:{width:a,height:i}}var x={a4:{top:12,right:15,bottom:15,left:15},a5:{top:10,right:12,bottom:12,left:12},a5l:{top:8,right:10,bottom:12,left:10},a6:{top:8,right:10,bottom:10,left:10},thermal:{top:2,right:2,bottom:2,left:2},thermal58:{top:1,right:1,bottom:1,left:1},tag:{top:1,right:1,bottom:1,left:1}};function S(e){return`${e.top}mm ${e.right}mm ${e.bottom}mm ${e.left}mm`}var ee=.75;function C({children:e,title:t,docNumber:n,docType:r,recordId:a,createdAt:u,size:p=`a4`,showQR:m=!0,qrLabel:y=`Verify`,qrPosition:C=`header`,footerLine:te,autoFit:w=!0,branchId:T}){let{firm:E,branding:D,branches:O,selectedBranchId:k}=i(),A=d(e=>e.sizeOverride),j=d(e=>e.orientation),M=d(e=>e.margins),N=d(e=>e.scalePct),P=d(e=>e.fitToPage),F=A??p,I=h.includes(F)?j??g(F):g(F),L=M??x[F],R=b(F,I),z=N/100,B=T||k||`MAIN`,V=O.find(e=>e.id===B),H=V?.address||E.address,U=V?.phone||E.phone,W=V?.gstin||E.gstin,G=(0,l.useRef)(null),[K,q]=(0,l.useState)(1),J=R?(R.height-L.top-L.bottom)*v:void 0,Y=R?(R.width-L.left-L.right)*v:void 0,X=w&&P&&J!==void 0&&Y!==void 0;(0,l.useLayoutEffect)(()=>{if(!X||!J||!Y||!G.current)return;let e=()=>{let e=G.current;if(!e)return;e.style.zoom=``;let t=e.scrollHeight,n=Math.max(e.scrollWidth,e.clientWidth),r=t>J?J/t:1,i=n>Y?Y/n:1,a=Math.min(r,i);q(a<1?Math.max(i<r?.4:ee,a):1)};e();let t=new ResizeObserver(e);return t.observe(G.current),()=>t.disconnect()},[X,J,Y,e]);let Z={a4:`w-[210mm] p-8 mx-auto bg-white text-black border border-stone-200 shadow-md print:border-none print:p-0 print:shadow-none print:w-full print:min-h-0`,a5:`w-[148mm] p-6 mx-auto bg-white text-black border border-stone-200 shadow-sm print:border-none print:p-0 print:shadow-none print:w-full print:min-h-0`,a5l:`w-[210mm] p-5 mx-auto bg-white text-black border border-stone-200 shadow-sm print:border-none print:p-0 print:shadow-none print:w-full print:min-h-0`,a6:`w-[105mm] p-4 mx-auto bg-white text-black border border-stone-200 shadow-sm print:border-none print:p-0 print:shadow-none print:w-full print:min-h-0`,thermal:`w-[80mm] p-4 mx-auto bg-white text-black border border-stone-200 print:border-none print:p-0 print:shadow-none print:w-full print:min-h-0`,thermal58:`w-[58mm] p-2 mx-auto bg-white text-black border border-stone-200 print:border-none print:p-0 print:shadow-none print:w-full print:min-h-0`,tag:`w-[50mm] p-2 mx-auto bg-white text-black border border-stone-100 print:border-none print:p-0 print:shadow-none print:w-full print:min-h-0`},Q=F===`thermal`||F===`thermal58`||F===`tag`,$=`print-root-${(0,l.useId)().replace(/:/g,``)}`;return(0,f.jsxs)(`div`,{id:$,className:Z[F],"data-testid":`print-layout-root`,"data-print-size":F,"data-print-orientation":I,style:{...z===1?{}:{zoom:z},...R?{width:`${R.width}mm`,minHeight:`${R.height}mm`}:{}},children:[(0,f.jsx)(`style`,{children:`
        @media print {
          body {
            background-color: white !important;
            color: black !important;
            margin: 0 !important;
            padding: 0 !important;
            -webkit-print-color-adjust: exact !important;
            print-color-adjust: exact !important;
            font-family: "Inter", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif !important;
          }
          .no-print, [data-testid="print-toolbar"], header, footer, nav, aside {
            display: none !important;
          }
          /* The on-screen sheet is sized in mm so the preview is physically
             true; on paper the page box already IS that sheet, so the root
             fills it instead of overflowing it by its own margins. */
          #${$} {
            width: 100% !important;
            min-height: 0 !important;
          }
          /* The real page: the size and margins the user actually chose.
             printToPDF runs with preferCSSPageSize, and printDocument()
             carries this very rule into the print window — so this is what
             the printer is told, not a decorative default. */
          @page {
            size: ${_(F,I)};
            margin: ${S(L)};
          }
          /* High-Contrast Table Border Enforcement */
          table {
            border-collapse: collapse !important;
            width: 100% !important;
          }
          th, td {
            border: 1px solid #78716c !important; /* stone-500 deep gray border */
            -webkit-print-color-adjust: exact !important;
            print-color-adjust: exact !important;
          }
          thead {
            display: table-header-group !important;
            background-color: #f5f5f4 !important; /* stone-100 */
          }
          tr {
            page-break-inside: avoid !important;
            break-inside: avoid !important;
          }
          /* Text clipping and spacing fixes */
          h1, h2, h3, h4, p, span, div, td {
            word-break: break-word !important;
            overflow-wrap: break-word !important;
          }
        }
      `}),Q?(0,f.jsxs)(`div`,{className:`text-center border-b border-dashed border-stone-400 pb-2 mb-3`,children:[(0,f.jsx)(`h2`,{className:`font-serif text-sm font-bold tracking-tight text-stone-900`,children:E.shopName||D.printHeader||D.companyName||D.applicationName}),(0,f.jsxs)(`div`,{className:`text-[9px] font-mono text-stone-600 leading-tight`,children:[t,` · `,(0,f.jsx)(`span`,{className:`font-semibold`,children:n})]}),u&&(0,f.jsx)(`div`,{className:`text-[8px] text-stone-500 font-mono`,children:new Date(u).toLocaleString(`en-IN`,{dateStyle:`short`,timeStyle:`short`})})]}):(0,f.jsxs)(`div`,{className:`flex justify-between items-start border-b-2 border-stone-300 pb-4 mb-6`,children:[(0,f.jsxs)(`div`,{className:`space-y-1`,children:[(0,f.jsxs)(`div`,{className:`flex items-center gap-3 mb-1`,children:[(0,f.jsx)(o,{variant:`png`,className:`h-12 w-12 object-contain flex-shrink-0`}),(0,f.jsx)(`h1`,{className:`font-serif text-2xl font-bold tracking-tight text-stone-900 leading-none`,children:D.printHeader||E.shopName||D.applicationName})]}),(E.tagline||D.tagline)&&(0,f.jsx)(`p`,{className:`text-[10px] italic font-medium text-stone-600 uppercase tracking-wider`,children:E.tagline||D.tagline}),(0,f.jsx)(`p`,{className:`text-xs text-stone-600 font-mono mt-1 max-w-sm leading-relaxed`,children:H}),V&&V.id!==`MAIN`&&(0,f.jsxs)(`p`,{className:`text-[10px] font-semibold text-stone-700`,children:[`(`,V.name,`)`]}),U&&(0,f.jsxs)(`p`,{className:`text-xs text-stone-500 font-mono`,children:[`Phone: `,(0,f.jsx)(`span`,{className:`font-semibold`,children:U}),E.email&&(0,f.jsxs)(`span`,{children:[` · `,E.email]})]}),E.website&&(0,f.jsxs)(`p`,{className:`text-xs text-stone-500 font-mono`,children:[`Web: `,(0,f.jsx)(`span`,{className:`font-semibold`,children:E.website})]})]}),(0,f.jsxs)(`div`,{className:`text-right flex flex-col items-end gap-2`,children:[(0,f.jsx)(`div`,{className:`inline-block bg-stone-100 border border-stone-300 px-3 py-1.5 rounded`,children:(0,f.jsx)(`span`,{className:`font-serif text-sm font-bold uppercase tracking-wider text-black`,children:t})}),(0,f.jsxs)(`div`,{className:`font-mono text-xs text-stone-800 space-y-0.5`,children:[(0,f.jsxs)(`div`,{children:[`Doc No: `,(0,f.jsx)(`strong`,{className:`font-semibold`,children:n})]}),u&&(0,f.jsxs)(`div`,{children:[`Date: `,new Date(u).toLocaleString(`en-IN`,{dateStyle:`medium`})]}),W&&(0,f.jsxs)(`div`,{className:`text-[10px] font-semibold text-stone-600`,children:[`GST: `,W]})]}),m&&C===`header`&&r&&a&&(0,f.jsx)(`div`,{className:`mt-1`,children:(0,f.jsx)(s,{docType:r,docNumber:n,recordId:a,createdAt:u,size:64,label:y})})]})]}),(0,f.jsx)(`div`,{ref:G,className:`flex-1 min-h-[1.5in]`,style:X&&K<1?{zoom:K}:void 0,children:e}),Q?(0,f.jsxs)(`div`,{className:`mt-4 pt-1.5 border-t border-dashed border-stone-400 text-center text-[8px] font-mono text-stone-600 space-y-1`,children:[(0,f.jsx)(`div`,{children:`Thank you for your valued custom.`}),(0,f.jsx)(`div`,{className:`text-[7px] text-stone-500 uppercase`,children:`Verified Transaction Copy`}),m&&r&&a&&(0,f.jsx)(`div`,{className:`pt-2 flex justify-center`,children:(0,f.jsx)(s,{docType:r,docNumber:n,recordId:a,createdAt:u,size:56,label:y})}),(0,f.jsx)(c,{className:`mt-2 text-[7px]`})]}):(0,f.jsxs)(`div`,{className:`mt-12`,children:[(0,f.jsxs)(`div`,{className:`border-t border-dashed border-stone-300 pt-4 text-center`,children:[(0,f.jsx)(`p`,{className:`text-[10px] text-stone-600 font-serif italic`,children:te||E.footerLine||`Official transaction record. Handcrafted quality and guaranteed purity.`}),(0,f.jsx)(`div`,{className:`text-[8px] font-mono text-stone-400 mt-1 tracking-wider uppercase`,children:`SYSTEM VERIFIED ORIGINAL COPY · HIGH-CONTRAST INKJET/LASER OPTIMIZED`})]}),(0,f.jsxs)(`div`,{className:`flex items-center justify-between mt-4`,children:[m&&C===`footer`&&r&&a&&(0,f.jsx)(`div`,{className:`shrink-0`,children:(0,f.jsx)(s,{docType:r,docNumber:n,recordId:a,createdAt:u,size:64,label:y})}),(0,f.jsx)(`div`,{className:`flex-1 min-w-0`,children:(0,f.jsx)(c,{className:`mt-0`})})]})]})]})}export{g as a,b as c,C as i,d as l,x as n,S as o,p as r,_ as s,h as t};